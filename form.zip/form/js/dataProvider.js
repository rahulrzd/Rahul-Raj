dataProvider = 
{
	submitQuote: function(values, callback)
	{
		$.ajax({
			type: 'POST',
			url: 'service.php',
			dataType: 'json',
			data: 
			{
				f: 'submitQuote',
				values: values
			}
		})
		.done(function(res)
		{
			if(callback) callback(res);
		});
	},
	updateQuote: function(id, values, callback)
	{
		$.ajax({
			type: 'POST',
			url: 'service.php',
			dataType: 'json',
			data: 
			{
				f: 'updateQuote',
				id: id,
				values: values
			}
		})
		.done(function(res)
		{
			if(callback) callback(res);
		});
	},
	loadCustData: function(id, callback)
	{
		$.ajax({
			type: 'GET',
			url: 'service.php',
			dataType: 'json',
			data: 
			{
				f: 'loadCustData',
				id: id
			}
		})
		.done(function(res)
		{
			if(callback) callback(res);
		});
	},
	termsItems: function(id, values, callback)
	{
		$.ajax({
			type: 'POST',
			url: 'service.php',
			dataType: 'json',
			data: 
			{
				f: 'termsItems',
				id: id,
				values: values
			}
		})
		.done(function(res)
		{
			if(callback) callback(res);
		});
	},
	termsSubmit: function(id, callback)
	{
		$.ajax({
			type: 'POST',
			url: 'service.php',
			dataType: 'json',
			data: 
			{
				f: 'termsSubmit',
				id: id
			}
		})
		.done(function(res)
		{
			if(callback) callback(res);
		});
	},
	msgHide: function()
	{
		$('#msg').empty();
	},
	scrollToTop: function()
	{
		$('body, html').animate({scrollTop:0}, 'slow');
	},
	scrollToBottom: function()
	{
		$('body, html').animate({scrollTop:$(document).height()}, 'slow');
	},
	scrollToElement: function(element, offset)
	{
		var el = $(element).offset().top;
		var of = typeof(offset) != 'undefined' ? offset : 0;
		var pos = el - of;
		
		$('body, html').animate({scrollTop:pos}, 'slow');
	},
	clearForm: function(ele)
	{
		$(ele).find(':input').each(function()
		{
			switch(this.type)
			{
				case 'password':
				case 'select-multiple':
				case 'select-one':
				case 'text':
				case 'textarea':
					$(this).val('');
					break;
				case 'checkbox':
					$(this).prop('checked', false).val(0);
				case 'radio':
					$(this).prop('checked', false);
			}
		});
	}
}