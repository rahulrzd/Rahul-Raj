loader = 
{
	isNumberKey: function(evt)
	{
		var charCode = (evt.which) ? evt.which : event.keyCode
		if (charCode > 31 && (charCode < 48 || charCode > 57))
			return false;
		return true;
	},
	buildCategory: function(res, id, headerId, dataId)
	{
		var categoryDataStr = '';
		
		$.each(res.categories[id].data, function(key, value)
		{
			categoryDataStr += '<div class="col-xs-12 col-md-4"><div>'+value.item+'</div><lable class="input"><input type="number" name="'+value.item_name+'" id="'+value.item_name+'" title="'+value.item+'" value="0" min="0" max="100" step="1" onkeypress="return loader.isNumberKey(event)"></lable></div>';
		});
		
		//major_appliances_oversized_items
		$(headerId).text(res.categories[id].category);
		$(dataId + ' .row').append(categoryDataStr);
	},
	estimateRequest: function()
	{
		var previousNumItem = '';
		
		dataProvider.loadCustData(id, function(res)
		{
			//console.log(res);
			
			// Kitchen/Dining Room
			loader.buildCategory(res, 1, '#kitchen_dining_room_header', '#kitchen_dining_room');
			
			// Living/Family Room
			loader.buildCategory(res, 3, '#living_family_room_header', '#living_family_room');
			
			// Misc Items/Odds & Ends
			loader.buildCategory(res, 7, '#misc_items_header', '#misc_items');
			
			// Bedroom
			loader.buildCategory(res, 4, '#bedroom_header', '#bedroom');

			// Office
			loader.buildCategory(res, 6, '#office_header', '#office');
			
			// Major Appliance
			loader.buildCategory(res, 8, '#major_appliances_oversized_items_header', '#major_appliances_oversized_items');
			
			if(typeof(res.cust_data.data) != 'undefined')
			{
				// process the object so that we can record the final list
				if(res.isValidUser === true && id)
				{
					$('#what_we_are_moving input, #what_we_are_moving textarea, #what_we_are_moving select, #addtl_items input').each(function()
					{
						var input_name = $(this).attr('name');
						var input_id = $(this).attr('id');
						
						// use the final data if it is not empty, otherwise replace it with the non final data
						if(res.cust_data.data[input_name + '_final'] == '')
						{
							res.cust_data.data[input_name + '_final'] = res.cust_data.data[input_name];
						}
						
						// change the name/id attributes for all inputs in this section to "xxx_final"
						$(this).attr('name', input_name + '_final');
						$(this).attr('id', input_id + '_final');
					});
					
					if(res.cust_data.data.pickup_stairs === 'Yes')
						$('#pickup_num_stairs_container').show();
					else
						$('#pickup_num_stairs_container').hide();
					
					if(res.cust_data.data.pickup_stairs_2 === 'Yes')
						$('#pickup_num_stairs_2_container').show();
					else
						$('#pickup_num_stairs_2_container').hide();
					
					if(res.cust_data.data.dropoff_stairs === 'Yes')
						$('#dropoff_num_stairs_container').show();
					else
						$('#dropoff_num_stairs_container').hide();
					
					if(res.cust_data.data.dropoff_stairs_2 === 'Yes')
						$('#dropoff_num_stairs_2_container').show();
					else
						$('#dropoff_num_stairs_2_container').hide();

					//add readonly for returning user
					$('#move_date').prop('readonly', true);
				}
				
				$.each(res.cust_data.data, function(key, value)
				{
					// Sets all input values by name attribute since there are duplicate inputs
					$('input[name="'+key+'"]').not(':radio').val(value);
					$('textarea[name="'+key+'"]').val(value);
					$('select[name="'+key+'"]').val(value);
				});
				
				if(res.cust_data.data.move_date_flexibility == 1)
				{
					$("#move_date_flexibility").prop('checked', true);
					$('#move_date_flexibility_notes').show();
				}
				
				if(res.cust_data.data.type_of_move == 'residential')
				{
					$('#option_residential').prop('checked', true);
					$('#option_residential').click();
				}
				else if(res.cust_data.data.type_of_move == 'business')
				{
					$('#option_business').prop('checked', true);
					$('#option_business').click();
				}
				else if(res.cust_data.data.type_of_move == 'labor only')
				{
					$('#option_labor').prop('checked', true);
					$('#option_labor').click();
				}
				else if(res.cust_data.data.type_of_move == 'cheap truck')
				{
					$('#option_cheap_truck').prop('checked', true);
					$('#option_cheap_truck').click();
				}
				
				$('#residential_move').val(res.cust_data.data.residential_move);
				$('#office_move').val(res.cust_data.data.office_move);
				$('#labor_only').val(res.cust_data.data.labor_only);
				$('#cheap_truck').val(res.cust_data.data.cheap_truck);
			}
			
			if(res.isValidUser)
			{
				$('#submit_quote').remove();
				$('#move_date').prop('disabled', true);
				$('#header-text').text('Final Updated List');
			}
			else
			{
				$('#update_quote, #addtl_items').remove();
				$('#header-text').text('Estimate Request Form');
			}
			
			// When user clicks in the textfield the text will go away and then will be restored when they click on something else
			$('#what_we_are_moving input, .frontend_adtl_items input').focus(function()
			{
				previousNumItem = $(this).val();
				$(this).val('');
			});
			
			$('#what_we_are_moving input, .frontend_adtl_items input').blur(function()
			{
				if($(this).val() == '')
					$(this).val(previousNumItem);
			});
			
			$('#form1 :checkbox').click(function()
			{
				if($(this).is(':checked'))
					$(this).val(1);
				else
					$(this).val(0);
			});
			
			$("#move_date").datepicker({ autoSize: true, minDate: new Date() });
			
			$('#move_date_flexibility').click(function()
			{
				if($(this).val() == 1)
					$('#move_date_flexibility_notes, #additional_dates').show();
				else
					$('#move_date_flexibility_notes, #additional_dates').hide();
			});
			
			$('#form1').validator()
				.on('submit', function (e)
				{
					if(e.isDefaultPrevented())
					{
						$('#msg').text('Some fields are missing data. Please scroll up and fill in required fields.');
						dataProvider.scrollToBottom();
						
						//dataProvider.scrollToElement('#' + invalidFields[0].field.id, 25);
					}
					else
					{
						var values = {};
						
						$('#form1 :input').not(':button').each(function()
						{
							if($(this).attr('type') == 'radio')
							{
								if($(this).prop('checked') == true)
									values[this.name] = $(this).val();
							}
							else
								values[this.name] = $(this).val();
						});
						
						if(res.isValidUser)
						{
							$('#update_quote').hide();

							dataProvider.updateQuote(id, values, function(res)
							{
								$('#msg').text(res.msg);
								dataProvider.scrollToBottom();
							});
						}
						else
						{
							$('#submit_quote').hide();

							dataProvider.submitQuote(values, function(res)
							{
								window.location.href = '/thankyou.php';
							});
						}
					}

					return false;
				});
		});
	},
	terms: function()
	{
		dataProvider.loadCustData(id, function(res)
		{
			if(res.isValidUser === true)
			{
				if(res.cust_data.data.move_type == 'cheap truck')
					var template = '../terms_cheap_truck.html';
				else
					var template = '../terms_default.html';
				
				$('#agree #form1 #content').load(template, function()
				{
					if(typeof(res.cust_data.data) != 'undefined')
					{
						$.each(res.cust_data.data, function(key, value)
						{
							// Sets all input values by name attribute since there are duplicate inputs
							$("input[name='"+key+"']").val(value);
							$("textarea[name='"+key+"']").val(value);
							$("select[name='"+key+"']").val(value);
							
							if(key == 'move_date_flexibility' && value == 1)
							{
								$("#move_date_flexibility").prop('checked', true);
								$('#move_date_flexibility_notes').show();
							}
						});
					}

					$('#agree').show();
					
					$('#submit_agree').click(function()
					{
						dataProvider.termsSubmit(id, function(res)
						{
							$('#submit_agree').hide();
							$('#msg').html(res.msg);
							
							if(res.move_type !== 'cheap truck')
							{
								console.log('not cheap truck');
								$('#deposit').show();
							}
							
							dataProvider.scrollToBottom();
						});
					});
					
					$('#submit_agree_additional_items').click(function()
					{
						var values = {};

						$('#form1 :input').not(':button').each(function()
						{
							values[this.name] = $(this).val();
						});
						
						dataProvider.termsItems(id, values, function(res)
						{
							$('#msg2').html(res.msg);
							dataProvider.scrollToBottom();
						});
					});
					
					if(res.cust_data.data.agree == 1)
					{
						if(res.cust_data.data.move_type === 'cheap truck')
						{
							$('#deposit').hide();
							$('#msg').text('You have already Agreed to the Terms.').show();
						}
						else
						{
							$('#deposit').show();
							$('#msg').text('You have already Agreed to the Terms. Please scroll to the bottom of the page to submit your deposit info and confirm your booking.').show();
						}
					}
					else
					{
						$('#deposit').hide();
						$('#submit_agree').show();
					}
					
					// set the customers ID in the hidden CustRefID value so that we can pass it to the payment gateway
					$('#CustRefID').val(res.cust_data.customer.id);
				});
			}
			else
			{
				$('#agree').html('<h1>An error has occured!</h1>').show();
			}
		});
	}
}