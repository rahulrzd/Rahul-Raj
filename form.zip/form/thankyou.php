<?php
//phpinfo();exit;
date_default_timezone_set('America/Los_Angeles');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<link rel="shortcut icon" type="image/jpg" href="favicon.jpg" />
    <title>Thank You - Submission Complete | REAL RocknRoll Movers Los Angeles Moving Company</title>

    <!-- jQuery Version 1.11.2 -->
    <script src="js/jquery-1.11.2.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

	<script type="text/javascript">
		var id = "<?=$_GET['id']?>";
	</script>
	<script type="text/javascript" src="js/dataProvider.js"></script>
	<script type="text/javascript" src="js/loader.js"></script>
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	<!--
	<script type="text/javascript" src="js/jquery.validationEngine.js"></script>
	<script type="text/javascript" src="js/jquery.validationEngine-en.js"></script>
	-->
	<script type="text/javascript" src="js/validetta.min.js"></script>

	<script type="text/javascript">
	$(document).ready(function()
	{
		loader.estimateRequest();
		
		$("#toggle1").click(function()
		{
			$("#Pickup2").slideToggle();
		});

		$("#toggle2").click(function()
		{
			$("#Dropoff2").slideToggle();
		});
	});
	</script>

    <link href='https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300' rel='stylesheet' type='text/css'>
    <!--<link href="css705/master.css" rel="stylesheet" type="text/css">-->
    <link rel="stylesheet" href="css705/demo.css">
    <link rel="stylesheet" href="css705/sky-forms.css">
    <link rel="stylesheet" href="css705/sky-forms-purple.css">
    <link rel="stylesheet" href="css705/innerdiv.css">
	<link rel="stylesheet" href="css705/jquery-ui.min.css">

    <!-- Bootstrap Core CSS -->
    <link href="css705/bootstrap.min.css" rel="stylesheet">

	<!--<link href="css705/validationEngine.jquery.css" rel="stylesheet">-->

	<link href="css705/validetta.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <style>
    body {
        /*padding-top: 70px;*/
        /* Required padding for .navbar-fixed-top. Remove if using .navbar-static-top. Change if height of navigation changes. */
    }
    </style>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!--Font Awesome-->    
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	
    <style>
    #Pickup2 {
        display: none;
    }
    #Dropoff2 {
        display: none;
    }

	#ui-datepicker-div
	{
		z-index: 10 !important;
	}
    </style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39698740-1', 'auto');
  ga('send', 'pageview');

</script>

</head>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-static-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!--<a class="navbar-brand" href="#">Start Bootstrap</a>-->
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
                <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="https://realrocknroll.com/" class="text_nav_option"><span>//</span> <p>Home</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/our-services/" class="text_nav_option"><span>//</span> <p>Our Services</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/about-us/" class="text_nav_option"><span>//</span> <p>About Us</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/moving-packing-tips-tricks-hacks/" class="text_nav_option"><span>//</span> <p>Moving Tips</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/moving-faqs/" class="text_nav_option faq"><span>//</span> <p>Faqs</p></a>
                    </li>
                    <li>
                        <a href="https://hire.wheniwork.com/jobs/realrocknrollmovers-1/f572fe2c-1bc5-441c-9d3c-b6562ded1ef3" target="_new" class="text_nav_option"><span>//</span> <p>Join The Team</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/contact-us/" class="text_nav_option"><span>//</span> <p>Contact Us</p></a>
                    </li>
					<!--
                    <li>
                        <a href="/" class="text_nav_option estimate_button"><span>//</span> <p>Get An Estimate</p></a>
                    </li>
					-->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	
    <div class="body">
        <form id="form1" name="form1" class="sky-form">
            <header>
				<h1>Thank You!</h1>
				<div style="font-size: 20px; font-weight:bold;">We Have Received Your Estimate Request.<br /> 
				We Will Be In Touch With You Shortly.<br />
				In The Meantime, Check Out Our <a href="https://realrocknroll.com/tips.php" style="color: #B20000; text-decoration: underline !important;">7 Ways To Speed Up Your Move and Save Money</a></div>
            </header>
            
			
</body>
</html>