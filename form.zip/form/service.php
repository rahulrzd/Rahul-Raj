<?php

$server_name = explode('.', $_SERVER['SERVER_NAME']);
//print_r($server_name);exit;

if($server_name[0] == 'form')
	$baseUrl = 'https://admin.realrocknroll.com';
else
	$baseUrl = 'https://dev.admin.realrocknroll.com';

switch ($_REQUEST['f'])
{
	case 'submitQuote':
        submitQuote($_POST['values']);
        break;
	case 'updateQuote':
        updateQuote($_POST['id'], $_POST['values']);
        break;
    case 'loadCustData':
        loadCustData($_GET['id']);
        break;
	case 'termsItems':
        termsItems($_POST['id'], $_POST['values']);
        break;
	case 'termsSubmit':
        termsSubmit($_POST['id']);
        break;
}

function submitQuote($values)
{
	global $baseUrl;
	$ch = curl_init();

	$url = $baseUrl.'/estimate_request/submitData';
	
	$postData = array(
        'values' => $values
    );

	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, count($postData));
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));

	$res = curl_exec($ch);

	if($res === FALSE)
	echo 'Curl error: ' . curl_error($ch);

	curl_close($ch);

	//echo '<pre>'.print_r($res, true).'</pre>';

	echo $res;
}

function updateQuote($id, $values)
{
	global $baseUrl;
	$ch = curl_init();

	$url = $baseUrl.'/estimate_request/updateData';
	
	$postData = array(
		'id' => $id,
        'values' => $values
    );
	
	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, count($postData));
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));

	$res = curl_exec($ch);
	
	if($res === FALSE)
	echo 'Curl error: ' . curl_error($ch);

	curl_close($ch);

	//echo '<pre>'.print_r($res, true).'</pre>';

	echo $res;
}

function loadCustData($id)
{
	global $baseUrl;
	$ch = curl_init();

	$url = $baseUrl.'/estimate_request/loadCustData/?id='.$id;
	
	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 

	$res = curl_exec($ch);

	if($res === FALSE)
	echo 'Curl error: ' . curl_error($ch);

	curl_close($ch);

	//echo '<pre>'.print_r($res, true).'</pre>';

	echo $res;
}

function termsItems($id, $values)
{
	global $baseUrl;
	$ch = curl_init();

	$url = $baseUrl.'/estimate_request/terms_items';
	
	$postData = array(
		'id' => $id,
        'values' => $values
    );
	
	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, count($postData));
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));

	$res = curl_exec($ch);
	
	if($res === FALSE)
	echo 'Curl error: ' . curl_error($ch);

	curl_close($ch);

	//echo '<pre>'.print_r($res, true).'</pre>';

	echo $res;
}

function termsSubmit($id)
{
	global $baseUrl;
	$ch = curl_init();

	$url = $baseUrl.'/estimate_request/terms_submit';
	
	$postData = array(
		'id' => $id,
        'values' => $values
    );
	
	curl_setopt($ch, CURLOPT_URL, $url); 
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, count($postData));
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($postData));

	$res = curl_exec($ch);
	
	if($res === FALSE)
	echo 'Curl error: ' . curl_error($ch);

	curl_close($ch);

	//echo '<pre>'.print_r($res, true).'</pre>';

	echo $res;
}
?>