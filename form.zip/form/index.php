<?php
//phpinfo();exit;
date_default_timezone_set('America/Los_Angeles');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="To start your move in Los Angeles, tell us about your move and we will get you a competitive quote from our movers." />
    <meta name="author" content="">
	<link rel="shortcut icon" type="image/jpg" href="favicon.jpg" />
    <title>Estimate Request Form | REAL RocknRoll Movers Los Angeles Moving Company</title>

    <!-- jQuery Version 1.11.2 -->
    <script src="js/jquery-1.11.2.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

	<script type="text/javascript">
		var id = "<?=$_GET['id']?>";
	</script>
	<script type="text/javascript" src="js/dataProvider.js"></script>
	<script type="text/javascript" src="js/loader.js"></script>
	<script type="text/javascript" src="js/jquery-ui.min.js"></script>
	<script type="text/javascript" src="js/validator.min.js"></script>
	<script type="text/javascript" src="js/jquery-input-mask-phone-number.js"></script>
	<script>
		$(document).ready(function()
		{
			$('#phone_num').usPhoneFormat({
				format: '(xxx) xxx-xxxx'
			});
		});
	</script>

    <link href='https://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,200,300' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css705/demo.css">
    <link rel="stylesheet" href="css705/sky-forms.css">
    <link rel="stylesheet" href="css705/sky-forms-purple.css">
    <link rel="stylesheet" href="css705/innerdiv.css">
	<link rel="stylesheet" href="css705/jquery-ui.min.css">

    <!-- Bootstrap Core CSS -->
    <link href="css705/bootstrap.min.css" rel="stylesheet">
	
	<link href="css705/validetta.min.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    <!--Font Awesome-->    
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
	
	<!-- Custom CSS -->
    <style>
    #Pickup2, #Dropoff2
	{
        display: none;
    }

	#ui-datepicker-div
	{
		z-index: 10 !important;
	}
    </style>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-39698740-1', 'auto');
  ga('send', 'pageview');

</script>
</head>
<body>

    <!-- Navigation -->
    <nav class="navbar navbar-inverse navbar-static-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!--<a class="navbar-brand" href="#">Start Bootstrap</a>-->
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="https://realrocknroll.com/" class="text_nav_option"><span>//</span> <p>Home</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/our-services/" class="text_nav_option"><span>//</span> <p>Our Services</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/about-us/" class="text_nav_option"><span>//</span> <p>About Us</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/moving-packing-tips-tricks-hacks/" class="text_nav_option"><span>//</span> <p>Moving Tips</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/moving-faqs/" class="text_nav_option faq"><span>//</span> <p>Faqs</p></a>
                    </li>
                    <li>
                        <a href="https://hire.wheniwork.com/jobs/realrocknrollmovers-1/f572fe2c-1bc5-441c-9d3c-b6562ded1ef3" target="_new" class="text_nav_option"><span>//</span> <p>Join The Team</p></a>
                    </li>
                    <li>
                        <a href="https://realrocknroll.com/contact-us/" class="text_nav_option"><span>//</span> <p>Contact Us</p></a>
                    </li>
					<!--
                    <li>
                        <a href="/" class="text_nav_option estimate_button"><span>//</span> <p>Get An Estimate</p></a>
                    </li>
					-->
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>
	
    <div class="body">
        <form id="form1" name="form1" class="sky-form" role="form" data-toggle="validator" novalidate="true">
            <header>
				<!-- <img src="images/los-angeles-mover-logo.png" alt="move for hunger logo" width="175" class="hunger"> -->
				<!-- <img src="images/movers-los-angeles-xmas.jpg" alt="get a moving estimate" width="250"><br> -->
				<img src="images/header-estimate-quote-movers.png" alt="get a moving estimate" width="250"><br> 
				<?php if(!empty($_GET['id'])): ?>
					<h2><strong>Final Updated List</strong></h2>
				<?php else: ?>
					<h2><strong>Estimate / Booking Form</strong></h2>
					<!-- <h4 style="color: rgba(126, 0, 0);">For general rate info check out our <a href="https://realrocknroll.com" style="color: #000; text-decoration: underline !important; font-weight: bold;">Quick Quote</a> form<br><br></h4> -->

<!-- <h3><strong>Response to the Safe At Home order in CA: </strong><br></h2>
<h4>As moving is considered an essential service, REAL RocknRoll Movers will continue to operate through this period. Our client and crew safety is very important to us. Our crew have all been instructed on safety protocol and we have supplies on hand including gloves, face covering and cleaning products. <br><br></h4>-->
				<?php endif; ?>

				  <h4>
					Office Booking Hours<br>
					Mon-Fri: 8am - 5pm<br>
					Sat & Sun: 8am - 2pm<br></h4>
					<!-- <h4>Our office staff will be working remotely with no access to the phone, <br> so if you need to reach us please email us at <a href="mailto:booking@realrocknroll.com" style="color: #000;"><strong><u>booking@realrocknroll.com</u></strong></a></h4> -->

<!-- <br><h4 style="color:#610303;"><strong>Temporarily Closed</strong><br>
With the rapid rise of COVID-19 cases in the LA area, and a true concern for the health and safety of our clients as well as our staff, we will be closed until further notice. This was a very difficult decision but we feel it is necessary to do our part to protect people during this crisis. We hope you all stay safe and healthy during this unprecedented time in life and we will see you all on the other side of this. <br><br> Sincerely, <br>The RRnR Movers Team</h4> -->

					<a href="tel:+18188597625" style="color: #000; text-decoration: underline !important;"><strong>(818) 859-7625</strong></a><br><br>
					<!--<span style="color: rgba(126, 0, 0);"><strong>HOLIDAY SCHEDULE</strong></span><br>
					<font color="green"><strong>We will be <span style="color: rgba(126, 0, 0);">CLOSED</span> to ROCK some Holiday <span style="color: rgba(126, 0, 0);">Dec 23rd - 26th & Dec 31st - Jan 1st.</span><br> We will be open all other dates!</strong></font> -->
				</h4>
			
            </header>
							
			<fieldset>
				<div class="row">
					<section class="col-md-3">
						<div class="form-group">
							<label>Move Date</label>
							<label class="input">
								<input type="text" name="move_date" id="move_date" autocomplete="off" placeholder="Move Date" readonly="readonly" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-5">
						<label>Move Type</label>
						<div class="form-group inline-group">
							<div class="radio">
							  <label>
								<input name="type_of_move" id="option_residential" type="radio" value="residential" required><i></i>&nbsp;&nbsp;Residential
							  </label>
							</div>
							<div class="radio">
							  <label>
								<input name="type_of_move" id="option_business" type="radio" value="business" required><i></i>&nbsp;&nbsp;Business
							  </label>
							</div>
							<div class="radio">
							  <label>
								<input name="type_of_move" id="option_labor" type="radio" value="labor only" required><i></i>&nbsp;&nbsp;Labor Only (no truck)
							  </label>
							</div>			
						  </div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>Move Size</label>
							<label class="select">
							<i class="fa fa-sort"></i>
								<select name="residential_move" id="residential_move" style="display: none" title="Select Residential Move (# of bedrooms)" required>
									<option value=""></option>
									<option value="Studio">Studio</option>
									<option value="1">1 Bedroom</option>
									<option value="2">2 Bedrooms</option>
									<option value="3">3 Bedrooms</option>
									<option value="4">4 Bedrooms</option>
									<option value="5">5 Bedrooms</option>
								</select>
								<select name="office_move" id="office_move" style="display: none" title="Select Office Move (# of suites)" required>
									<option value=""></option>
									<option value="1-3">1-3 Suites</option>
									<option value="4-7">4-7 Suites</option>
									<option value="7-10">7-10 Suites</option>
									<option value="10+">10+ Suites</option>
								</select>
								<select name="labor_only" id="labor_only" style="display: none" title="Select Type of Move" required>
									<option value=""></option>
									<option value="Studio">Studio</option>
									<option value="1">1 Bedroom</option>
									<option value="2">2 Bedrooms</option>
									<option value="3">3 Bedrooms</option>
									<option value="4">4 Bedrooms</option>
									<option value="5">5 Bedrooms</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
			</fieldset>
			
			<fieldset>
				<div class="row">
					<div class="sectionLable"><img src="images/estimate_who_move-trans.png"></div>
					<section class="col-md-4">
						<div class="form-group">
							<label>First Name</label>
							<label class="input">
								<i class="icon-prepend icon-user"></i>
								<input type="text" name="first_name" id="first_name" placeholder="First Name" <?php echo (!empty($_GET['id'])) ? 'readonly="readonly"' : '' ?> required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>Last Name</label>
							<label class="input">
								<i class="icon-prepend icon-user"></i>
								<input type="text" name="last_name" id="last_name" placeholder="Last Name" <?php echo (!empty($_GET['id'])) ? 'readonly="readonly"' : '' ?> required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>Contact Phone #</label>
							<label class="input">
								<i class="icon-prepend icon-phone"></i>
								<input type="text" name="phone_num" id="phone_num" placeholder="Contact Phone #" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
				<div class="row">
					<section class="col-md-6">
						<div class="form-group">
							<label>E-mail</label>
							<label class="input">
								<i class="icon-prepend icon-envelope"></i>
								<input type="email" name="email" id="email" placeholder="E-mail" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-6">
						<div class="form-group">
							<label>Confirm E-mail</label>
							<label class="input">
								<i class="icon-prepend icon-envelope"></i>
								<input type="email" name="email_2" id="email_2" placeholder="Confirm E-mail" data-match="#email" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
				<div class="row">
					<section class="col-md-4">
						<label><input type="checkbox" id="move_date_flexibility" name="move_date_flexibility" value="0" title="WANT THE BEST DEAL? Give us a date range for your move.">&nbsp;Do you have flexibility with your move date?</label>
						<label class="textarea">
                            <textarea name="move_date_flexibility_notes" id="move_date_flexibility_notes" style="display:none;width:100%;" placeholder="Note additional dates below."></textarea>
                        </label>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>How Did You Hear About Us?</label>
							<label class="select">
							<i class="fa fa-sort"></i>
							<select name="hear_about_us" id="hear_about_us" required>
								<option value=""></option>
								<option value="Facebook Ad">Facebook Ad</option>
								<option value="Instagram Ad">Instagram Ad</option>
								<option value="Apt Manager">Apt Manager</option>
								<option value="CBS">CBS</option>
								<option value="Courtney &amp; Kurt Real Estate">Courtney &amp; Kurt Real Estate</option>
								<option value="Dilbeck Real Estate">Dilbeck Real Estate</option>
								<option value="Door Hanger/Flier">Door Hanger/Flier</option>
								<option value="Drell">Drell</option>
								<option value="Friend">Friend</option>
								<option value="Google">Google</option>
								<option value="Kevin Hart">Kevin Hart</option>
								<option value="KLOS">KLOS</option>
								<option value="LA Weekly">LA Weekly</option>
								<option value="Media West Realty">Media West Realty</option>
								<option value="Michael">Michael</option>
								<option value="Realtor">Realtor</option>
								<option value="Repeat Customer">Repeat Customer</option>
								<option value="Saw Our Truck">Saw Our Truck</option>
								<option value="Storage Etc...">Storage Etc...</option>
								<option value="The Rental Girl">The Rental Girl</option>
								<option value="Yelp">Yelp</option>
								<option value="Other">Other</option>  
							</select>
							<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>Are you interested in packing services?</label>
							<label class="select">
							<i class="fa fa-sort"></i>
							<select name="packing_services" id="packing_services" required>
								<option value=""></option>
								<option value="Yes">Yes</option>
								<option value="No">No</option>
							</select>
							<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
            </fieldset>
			
            <fieldset>					
				<div class="row">
					<div class="sectionLable"><img src="images/estimate_where_move-trans.png"></div>
					<div class="sectionLable2" style="font-color: #7e0000 !important;"/><strong>Pickup Info</strong></div>
					<section class="col-md-4">
						<div class="form-group">
							<label>Pickup Street Address</label>
							<label class="input">
								<i class="icon-prepend icon-building"></i>
								<input type="text" name="pickup_address" id="pickup_address" placeholder="Street Address and Apt/Unit #" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>City</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
								<input type="text" name="pickup_city" id="pickup_city" placeholder="City" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>Zipcode</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
								<input type="text" name="pickup_zip" id="pickup_zip" placeholder="Zipcode" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
				<div class="row">
					<section class="col-md-6">
						<div class="form-group">
							<label>Part of town</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
								<input type="text" name="pickup_part_of_town" id="pickup_part_of_town" placeholder="Part of town" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-6">
						<div class="form-group">
							<label>Type of residence</label>
							<label class="select">
								<i class="fa fa-sort"></i>
								<select name="pickup_residence_type" id="pickup_residence_type" required>
									<option value=""></option>
									<option value="House">House</option>
									<option value="Apt/Condo">Apt/Condo</option>
									<option value="Storage Unit">Storage Unit</option>
									<option value="High Rise Building">High Rise Building</option>
									<option value="Office">Office</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
				<div class="row">
					<section class="col-md-3">
						<div class="form-group">
							<label>Are there stairs?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="pickup_stairs" id="pickup_stairs" required>
									<option value=""></option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-3" id="pickup_num_stairs_container">
						<div class="form-group">
							<label>If so, how many flights?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="pickup_num_stairs" id="pickup_num_stairs" required>
									<option value=""></option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-3">
						<div class="form-group">
							<label>Is there an Elevator?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="pickup_elevator" id="pickup_elevator" required>
									<option value=""></option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-3">
						<div class="form-group">
							<label>Number of steps from our truck to YOUR door</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="pickup_truck_distance" id="pickup_truck_distance" title="ALL the way to the actual front door of your unit? (Best to walk the route. Be sure to include hallways, walkways, garages etc...)" required>
									<option value="Not sure">Not sure</option>
									<option value="Close (0-25 steps)">Close (0-25 steps)</option>
									<option value="Short Walk (25-75 steps)">Short Walk (25-75 steps)</option>
									<option value="Long Walk (75+ steps)">Long Walk (75+ steps)</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>		
				<div class="row">
					<section class="col-md-12">
						<label>Additional Notes</label>
						<label class="textarea">
							<textarea type="text" name="pickup_notes" id="pickup_notes" placeholder="Additional Notes"></textarea>
						</label>
					</section>
				</div>
				<div class="row">
					<section class="col-md-12">
					<div id="toggle1" class="button" style="text-align: center;">Add Additional Pickup</div>
					</section>
				</div>
			</fieldset>
			
			<fieldset id="Pickup2">					
				<div class="row">
				<div class="sectionLable2"><strong>Pickup Info #2</strong></div>
					<section class="col-md-4">
						<label>Street Pickup #2 Address</label>
						<label class="input">
							<i class="icon-prepend icon-building"></i>
							<input type="text" name="pickup_address_2" id="pickup_address_2" placeholder="Street Address and Apt/Unit #"/>

						</label>
					</section>
					<section class="col-md-4">
						<label>City</label>
						<label class="input">
							<i class="icon-prepend icon-map-marker"></i>
							<input type="text" name="pickup_city_2" id="pickup_city_2" placeholder="City"/>
						</label>
					</section>
					<section class="col-md-4">
						<label>Zipcode</label>
						<label class="input">
							<i class="icon-prepend icon-map-marker"></i>
							<input type="text" name="pickup_zip_2" id="pickup_zip_2" placeholder="Zipcode"/>
						</label>
					</section>
				</div>
				<div class="row">
					<section class="col-md-6">
						<label>Part of town</label>
						<label class="input">
							<i class="icon-prepend icon-map-marker"></i>
							<input type="text" name="pickup_part_of_town_2" id="pickup_part_of_town_2" placeholder="Part of town"/>
						</label>
					</section>
					<section class="col-md-6">
						<label>Type of residence</label>
						<label class="select">
							<i class="fa fa-sort"></i>
							<select name="pickup_residence_type_2" id="pickup_residence_type_2">
								<option value=""></option>
								<option value="House">House</option>
								<option value="Apt/Condo">Apt/Condo</option>
								<option value="Storage Unit">Storage Unit</option>
								<option value="High Rise Building">High Rise Building</option>
								<option value="Office">Office</option>
							</select>
						</label>
					</section>
				</div>
				<div class="row">
					<section class="col-md-3">
						<label>Are there stairs?</label>
						<label class="select">   
							<i class="fa fa-sort"></i>
							<select name="pickup_stairs_2" id="pickup_stairs_2">
								<option value=""></option>
								<option value="Yes">Yes</option>
								<option value="No">No</option>
							</select>
						</label>
					</section>
					<section class="col-md-3" id="pickup_num_stairs_2_container">
						<label>If so, how many flights?</label>
						<label class="select">   
							<i class="fa fa-sort"></i>
							<select name="pickup_num_stairs_2" id="pickup_num_stairs_2">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
							</select>
						</label>
					</section>
					<section class="col-md-3">
						<label>Is there an Elevator?</label>
						<label class="select"> 
							<i class="fa fa-sort"></i>
							<select name="pickup_elevator_2" id="pickup_elevator_2">
								<option value=""></option>
								<option value="Yes">Yes</option>
								<option value="No">No</option>
							</select>
						</label>
					</section>
					<section class="col-md-3">
						<label>Number of steps from our truck to YOUR door</label>
						<label class="select">   
							<i class="fa fa-sort"></i>
							<select name="pickup_truck_distance_2" id="pickup_truck_distance_2" title="ALL the way to the actual front door of your unit? (Best to walk the route. Be sure to include hallways, walkways, garages etc...)">
								<option value="Not sure">Not sure</option>
								<option value="Close (0-25 steps)">Close (0-25 steps)</option>
								<option value="Short Walk (25-75 steps)">Short Walk (25-75 steps)</option>
								<option value="Long Walk (75+ steps)">Long Walk (75+ steps)</option>
							</select>
						</label>
					</section>
				</div>		
				<div class="row">
					<section class="col-md-12">
						<label>Additional Notes</label>
						<label class="textarea">
							<textarea type="text" name="pickup_notes_2" id="pickup_notes_2" placeholder="Additional Notes"></textarea>
						</label>
					</section>
				</div>
			</fieldset>
			
            <fieldset>					
				<div class="row">
				<div class="sectionLable2"><strong>Drop-Off Info</strong></div>
					<section class="col-md-4">
						<div class="form-group">
							<label>Drop-Off Street Address</label>
							<label class="input">
								<i class="icon-prepend icon-building"></i>
								<input type="text" name="dropoff_address" id="dropoff_address" placeholder="Street Address and Apt/Unit #" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>City</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
								<input type="text" name="dropoff_city" id="dropoff_city" placeholder="City" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-4">
						<div class="form-group">
							<label>Zipcode</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
								<input type="text" name="dropoff_zip" id="dropoff_zip" placeholder="Zipcode" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>
				<div class="row">
					<section class="col-md-6">
						<div class="form-group">
							<label>Part of town</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
								<input type="text" name="dropoff_part_of_town" id="dropoff_part_of_town" placeholder="Part of town" required />
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-6">
						<div class="form-group">
							<label>Type of residence</label>
							<label class="select">
								<i class="fa fa-sort"></i>
								<select name="dropoff_residence_type" id="dropoff_residence_type" required>
									<option value=""></option>
									<option value="House">House</option>
									<option value="Apt/Condo">Apt/Condo</option>
									<option value="Storage Unit">Storage Unit</option>
									<option value="High Rise Building">High Rise Building</option>
									<option value="Office">Office</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>					
				<div class="row">
					<section class="col-md-3">
						<div class="form-group">
							<label>Are there stairs?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="dropoff_stairs" id="dropoff_stairs" required>
									<option value=""></option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-3" id="dropoff_num_stairs_container">
						<div class="form-group">
							<label>If so, how many flights?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="dropoff_num_stairs" id="dropoff_num_stairs" required>
									<option value=""></option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-3">
						<div class="form-group">
							<label>Is there an Elevator?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="dropoff_elevator" id="dropoff_elevator" required>
									<option value=""></option>
									<option value="Yes">Yes</option>
									<option value="No">No</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
					<section class="col-md-3">
						<div class="form-group">
							<label>Number of steps from our truck to YOUR door</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="dropoff_truck_distance" id="dropoff_truck_distance" title="ALL the way to the actual front door of your unit? (Best to walk the route. Be sure to include hallways, walkways, garages etc...)" required>
									<option value="Not sure">Not sure</option>
									<option value="Close (0-25 steps)">Close (0-25 steps)</option>
									<option value="Short Walk (25-75 steps)">Short Walk (25-75 steps)</option>
									<option value="Long Walk (75+ steps)">Long Walk (75+ steps)</option>
								</select>
								<div class="help-block with-errors"></div>
							</label>
						</div>
					</section>
				</div>		
				<div class="row">
					<section class="col-md-12">
						<label>Additional Notes</label>
						<label class="textarea">
							<textarea type="text" name="dropoff_notes" id="dropoff_notes" placeholder="Additional Notes"></textarea>
						</label>
					</section>
				</div>
				<div class="row">
					<section class="col-md-12">
					<div id="toggle2" class="button" style="text-align: center;">Add Additional Drop-Off</div>
					</section>
				</div>
			</fieldset>
			
            <fieldset id="Dropoff2">					
					<div class="row">
                    <div class="sectionLable2"><strong>Drop-off Info 2</strong></div>
						<section class="col-md-4">
							<label>Street Address and Apt/Unit #</label>
							<label class="input">
								<i class="icon-prepend icon-building"></i>
                                <input type="text" name="dropoff_address_2" id="dropoff_address_2" placeholder="Street Address and Apt/Unit #"/>

							</label>
						</section>
						<section class="col-md-4">
							<label>City</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
                                <input type="text" name="dropoff_city_2" id="dropoff_city_2" placeholder="City"/>
							</label>
						</section>
						<section class="col-md-4">
							<label>Zipcode</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
                                <input type="text" name="dropoff_zip_2" id="dropoff_zip_2" placeholder="Zipcode"/>
							</label>
						</section>
					</div>
					<div class="row">
						<section class="col-md-6">
							<label>Part of town</label>
							<label class="input">
								<i class="icon-prepend icon-map-marker"></i>
                                <input type="text" name="dropoff_part_of_town_2" id="dropoff_part_of_town_2" placeholder="Part of town"/>
							</label>
						</section>
						<section class="col-md-6">
							<label>Type of residence</label>
							<label class="select">
								<i class="fa fa-sort"></i>
								<select name="dropoff_residence_type_2" id="dropoff_residence_type_2">
                                    <option value=""></option>
                                    <option value="House">House</option>
                                    <option value="Apt/Condo">Apt/Condo</option>
									<option value="Storage Unit">Storage Unit</option>
									<option value="High Rise Building">High Rise Building</option>
									<option value="Office">Office</option>
                                </select>
							</label>
						</section>
					</div>					
					<div class="row">
						<section class="col-md-3">
							<label>Are there stairs?</label>
							<label class="select">   
                                <i class="fa fa-sort"></i>
                                <select name="dropoff_stairs_2" id="dropoff_stairs_2">
                                    <option value=""></option>
									<option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
							</label>
						</section>
						<section class="col-md-3" id="dropoff_num_stairs_2_container">
							<label>If so, how many flights?</label>
							<label class="select">   
								<i class="fa fa-sort"></i>
								<select name="dropoff_num_stairs_2" id="dropoff_num_stairs_2">
									<option value=""></option>
									<option value="1">1</option>
									<option value="2">2</option>
									<option value="3">3</option>
									<option value="4">4</option>
									<option value="5">5</option>
								</select>
							</label>
						</section>
						<section class="col-md-3">
							<label>Is there an Elevator?</label>
							<label class="select"> 
                                <i class="fa fa-sort"></i>
                                <select name="dropoff_elevator_2" id="dropoff_elevator_2">
                                    <option value=""></option>
									<option value="Yes">Yes</option>
                                    <option value="No">No</option>
                                </select>
							</label>
						</section>
						<section class="col-md-3">
							<label>Number of steps from our truck to YOUR door</label>
							<label class="select">   
                                <i class="fa fa-sort"></i>
                                <select name="dropoff_truck_distance_2" id="dropoff_truck_distance_2" title="ALL the way to the actual front door of your unit? (Best to walk the route. Be sure to include hallways, walkways, garages etc...)">
									<option value="Not sure">Not sure</option>
									<option value="Close (0-25 steps)">Close (0-25 steps)</option>
									<option value="Short Walk (25-75 steps)">Short Walk (25-75 steps)</option>
									<option value="Long Walk (75+ steps)">Long Walk (75+ steps)</option>
                                </select>
							</label>
						</section>
					</div>		
					<div class="row">
						<section class="col-md-12">
							<label>Additional Notes</label>
							<label class="textarea">
                                <textarea type="text" name="dropoff_notes_2" id="dropoff_notes_2" placeholder="Additional Notes"></textarea>
							</label>
						</section>
					</div>
				</fieldset>
				
				<fieldset style="padding: 25px 30px;">
                    <div class="row">
                        <div class="sectionLable"><img src="images/estimate_what_move-trans.png">
                        <br><br>
                        <h5>**Please click and note the number of the items below. Without this info we cannot provide a quote.</h5>
                        </div>
                        <div id="what_we_are_moving" class="col-md-12">
                            <div class="row panel-group" id="accordion">
                                <div class="col-md-6">
                                    
									<div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne">
											<div class="panel-heading">
												<h4 id="kitchen_dining_room_header" class="panel-title"></h4>
											</div>
                                        </a>
                                        <div id="collapseOne" class="panel-collapse collapse">
                                            <div id="kitchen_dining_room" class="panel-body">
                                                <div class="row"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseTwo">
											<div class="panel-heading">
												<h4 id="living_family_room_header" class="panel-title"> </h4>
											</div>
                                        </a>
                                        <div id="collapseTwo" class="panel-collapse collapse">
                                            <div id="living_family_room" class="panel-body">
                                                <div class="row"></div>
                                            </div>
                                        </div>
                                    </div>
									
									 <div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseFour">
											<div class="panel-heading">
												<h4 id="bedroom_header" class="panel-title"></h4>
											</div>
                                        </a>
                                        <div id="collapseFour" class="panel-collapse collapse">
                                            <div id="bedroom" class="panel-body">
                                                <div class="row"></div>
                                            </div>
                                        </div>
                                    </div>
									
									<div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseFive">
											<div class="panel-heading">
												<h4 id="office_header" class="panel-title"></h4>
											</div>
                                        </a>
                                        <div id="collapseFive" class="panel-collapse collapse">
                                            <div id="office" class="panel-body">
                                                <div class="row"></div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="col-md-6 a2">
									
									<div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseThree">
											<div class="panel-heading">
												<h4 id="misc_items_header" class="panel-title"></h4>
											</div>
                                        </a>
                                        <div id="collapseThree" class="panel-collapse collapse">
                                            <div id="misc_items" class="panel-body">
                                                <div class="row"></div>
                                            </div>
                                        </div>
                                    </div>

									<div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseSix">
											<div class="panel-heading">
												<h4 id="major_appliances_oversized_items_header" class="panel-title"></h4>(Please no Pianos or items over 300 lbs)
											</div>
                                        </a>
                                        <div id="collapseSix" class="panel-collapse collapse">
                                            <div id="major_appliances_oversized_items" class="panel-body">
                                                <div class="row"></div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseEight">
											<div class="panel-heading" style="border: 3px solid #BF0505;">
												<h4 class="panel-title">
													# of Boxes <span style="color:#BF0505; font-weight: bold;"> *DON'T FORGET THIS</span>
												</h4>
											</div>
                                        </a>
                                        <div id="collapseEight" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-xs-12 col-md-4 pad5">
                                                      <lable class="select">
                                                            <i class="fa fa-sort"></i>
                                                            <select name="num_boxes_small" id="num_boxes_small">
                                                            <option value="">Small boxes</option>
                                                            <option value="None">None</option>
                                                            <option value="1-10">1-10</option>
                                                            <option value="11-25">11-25</option>
                                                            <option value="26-50">26-50</option>
                                                            <option value="51-75">51-75</option>
                                                            <option value="76-100">76-100</option>
                                                            <option value="100+">100+</option>
                                                            </select>
                                                        </lable>
                                                    </div>
                                                    <div class="col-xs-12 col-md-4 pad5">
                                                        <lable class="select">
                                                            <i class="fa fa-sort"></i>
                                                            <select name="num_boxes_medium" id="num_boxes_medium">
                                                            <option value="">Medium boxes</option>
                                                            <option value="None">None</option>
                                                            <option value="1-10">1-10</option>
                                                            <option value="11-25">11-25</option>
                                                            <option value="26-50">26-50</option>
                                                            <option value="51-75">51-75</option>
                                                            <option value="76-100">76-100</option>
                                                            <option value="100+">100+</option>
                                                            </select>
                                                        </lable>
                                                    </div>
                                                    <div class="col-xs-12 col-md-4 pad5">
                                                        <lable class="select">
                                                            <i class="fa fa-sort"></i>
                                                            <select name="num_boxes_large" id="num_boxes_large">
                                                            <option value="">Large boxes</option>
                                                            <option value="None">None</option>
                                                            <option value="1-10">1-10</option>
                                                            <option value="11-25">11-25</option>
                                                            <option value="26-50">26-50</option>
                                                            <option value="51-75">51-75</option>
                                                            <option value="76-100">76-100</option>
                                                            <option value="100+">100+</option>
                                                            </select>
                                                        </lable>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="panel panel-default">
                                        <a data-toggle="collapse" data-parent="#accordion" href="#collapseSeven">
											<div class="panel-heading">
												<h4 class="panel-title">
													Items NOT mentioned above/Additional notes
												</h4>
											</div>
                                        </a>
                                        <div id="collapseSeven" class="panel-collapse collapse">
                                            <div class="panel-body">
                                                <div class="row">
                                                    <div class="col-xs-12">
                                                        <label class="textarea">
                                                          <textarea name="items_not_mentioned" id="items_not_mentioned" style="width:100%;"></textarea>
                                                        </label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
				</fieldset>

            <footer>
				<!-- Returning User -->
				<div class="row">
					<div class="col-md-12">
						<div id="addtl_items" class="frontend_adtl_items">
							<h3 class="text-center"><strong>Additional Items and Services:</strong></h3>
							<div class="text-center">(Please let us know if you are interested in any of the additional items listed below so we can have them on hand for you.)</div>
							<br />
							<br />
							<div class="col-md-12">
								<strong>-Wardrobe Boxes-</strong> 2 boxes FREE to use for the day. $5 per additional box needed. Boxes are available for purchase for $20 each.
							</div>
							<br />
							<br />
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-1">
										<label class="input">
											<input type="text" name="wardrobe_boxes_rent" id="wardrobe_boxes_rent" class="qty" />
										</label>
									</div>
									<div class="col-md-11">
										<strong>Total wardrobe boxes to rent (NOT including 2 FREE ones)</strong>
									</div>
								</div>
							</div>
							<br />
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-1">
										<label class="input">
											<input type="text" name="wardrobe_boxes_buy" id="wardrobe_boxes_buy" class="qty" />
										</label>
									</div>
									<div class="col-md-11">
										<strong>Total wardrobe boxes to buy</strong>
									</div>
								</div>
							</div>
							<br />
							<br />
							<div class="col-md-12">
								<strong>-Mattress Bags-</strong> $10 per bag (helps keep the mattress clean during transport).
							</div>
							<br />
							<br />
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-1">
										<label class="input">
											<input type="text" name="mattress_bags_king" id="mattress_bags_king" />
										</label>
									</div>
									<div class="col-md-11">
										<strong>King</strong>
									</div>
								</div>
							</div>
							<br />
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-1">
										<label class="input">
											<input type="text" name="mattress_bags_queen" id="mattress_bags_queen" />
										</label>
									</div>
									<div class="col-md-11">
										<strong>Queen</strong>
									</div>
								</div>
							</div>
							<br />
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-1">
										<label class="input">
											<input type="text" name="mattress_bags_full" id="mattress_bags_full" />
										</label>
									</div>
									<div class="col-md-11">
										<strong>Full</strong>
									</div>
								</div>
							</div>
							<br />
							<div class="row">
								<div class="col-md-12">
									<div class="col-md-1">
										<label class="input">
											<input type="text" name="mattress_bags_twin" id="mattress_bags_twin" />
										</label>
									</div>
									<div class="col-md-11">
										<strong>Twin</strong>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
				<div class="row">
					<div class="col-md-12">
						<button type="submit" name="update_quote" id="update_quote" class="button">Update</button>
						<!-- Returning User -->
						
						<!-- New User -->
						<button type="submit" name="submit_quote" id="submit_quote" class="button"><h3><strong>SUBMIT</strong></h3></button>
					</div>
				</div>
				<div class="clearfix" style="margin-top:20px;"></div>
				<div class="row">
					<div class="col-md-12">
						<h3 id="msg" class="text-center"></h3>
					</div>
				</div>
            </footer>

			<input type="hidden" name="fsub">
        </form>

    </div>
    <script>
		function changeOptions()
		{
			var form = window.document.getElementById("form1");
			var residential = window.document.getElementById("residential_move");
			var business = window.document.getElementById("office_move");
			var labor = window.document.getElementById("labor_only");
			
			if (form.option_residential.checked)
			{
				business.style.display = "none";
				labor.style.display = "none";
				residential.style.display = "block";
				residential.selectedIndex = 0;
			}
			else if (form.option_business.checked)
			{
				residential.style.display = "none";
				labor.style.display = "none";
				business.style.display = "block";
				business.selectedIndex = 0;
			}
			else if (form.option_labor.checked)
			{
				residential.style.display = "none";
				business.style.display = "none";
				labor.style.display = "block";
				labor.selectedIndex = 0;
			}
		}
		window.document.getElementById("option_residential").onclick = changeOptions;
		window.document.getElementById("option_business").onclick = changeOptions;
		window.document.getElementById("option_labor").onclick = changeOptions;
		
		// set default selection
		document.getElementById('option_residential').checked = true;
		changeOptions();
		
		// 
		$(function()
		{
			loader.estimateRequest();
				
			$('#toggle1').click(function()
			{
				$('#Pickup2').slideToggle();
			});

			$('#toggle2').click(function()
			{
				$('#Dropoff2').slideToggle();
			});
			
			$('#pickup_stairs').on('change', function()
			{
				if($('#pickup_stairs').val() == 'Yes')
					$('#pickup_num_stairs_container').show();
				else
					$('#pickup_num_stairs_container').hide();
			});
			
			$('#pickup_stairs_2').on('change', function()
			{
				if($('#pickup_stairs_2').val() == 'Yes')
					$('#pickup_num_stairs_2_container').show();
				else
					$('#pickup_num_stairs_2_container').hide();
			});
			
			$('#dropoff_stairs').on('change', function()
			{
				if($('#dropoff_stairs').val() == 'Yes')
					$('#dropoff_num_stairs_container').show();
				else
					$('#dropoff_num_stairs_container').hide();
			});
			
			$('#dropoff_stairs_2').on('change', function()
			{
				if($('#dropoff_stairs_2').val() == 'Yes')
					$('#dropoff_num_stairs_2_container').show();
				else
					$('#dropoff_num_stairs_2_container').hide();
			});
			
			$('#accordion').on('show.bs.collapse', function()
			{
				$('#accordion .in').collapse('hide');
			});
		});
	
		// 
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-39698740-1']);
		_gaq.push(['_setDomainName', 'realrocknroll.com']);
		_gaq.push(['_setAllowLinker', true]);
		_gaq.push(['_trackPageview']);

		(function() {
		var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
		ga.src = ('https:' == document.location.protocol ? 'https://' : 'http://') + 'stats.g.doubleclick.net/dc.js';
		var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
		})();
	</script>
<center>Thank you for choosing REAL RocknRoll Movers, <a href="https://realrocknroll.com" style="color: #333;">rated best movers in los angeles</a>!</center>

</body>
</html>