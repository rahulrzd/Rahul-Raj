var employee_travel_rate = '8.00';

var total_hours_in_minutes = 0;
var travel_diff_in_minutes = 0;
var move_diff_in_minutes = 0;

var total_hours_in_minutes_alt = 0;
var travel_diff_in_minutes_alt = 0;
var move_diff_in_minutes_alt = 0;

var total_hours_in_minutes_details = 0;
var travel_diff_in_minutes_details = 0;
var move_diff_in_minutes_details = 0;

$(document).ready(function()
{
	$('#datepicker_entry_form, #datepicker_employee_totals_start, #datepicker_employee_totals_end').datepicker({
		autoSize: true,
		changeMonth: true,
		changeYear: true
	});
	
	var $tab = $('#tabs').tabs({
		ajaxOptions:
		{
			error: function(xhr, status, index, anchor)
			{
				$(anchor.hash).html('Could not load tab data.');
			}
		},
		spinner: 'Retrieving data...'
	}).bind('tabsselect', function(event, ui)
	{
		//console.log('PANEL: ' + ui.panel.id);
		
		if(ui.panel.id == 'tabs-add-employee')
		{
			//console.log('tabs-add-employee');
			
			$('#employees_container').show();
			$('#entry_form').hide();
			$('#employee_totals').hide();
			
			refresh_employee_dropdown();
		}
		else if(ui.panel.id == 'tabs-entry-form')
		{
			//console.log('tabs-entry-form');
			
			$('#employees_container').hide();
			$('#entry_form').show();
			$('#employee_totals').hide();
			
			var employees = $.parseJSON(get_employees('', '', true));
			
			if(employees.success)
			{
				$('#drivers_container').empty();
				$('#movers_container').empty();
				
				$.each(employees.result, function(index, value)
				{
					var full_name = value.first_name + ' ' + value.last_name
					
					if(value.driver == 1)
					{
						$('#drivers_container').append('<input type="checkbox" id="drivers_' + value.id + '" name="drivers" value="' + value.id + '" /><span>' + full_name + '</span><br />');
					}
					
					if(value.mover == 1)
					{
						$('#movers_container').append('<input type="checkbox" id="movers_' + value.id + '" name="movers" value="' + value.id + '" /><span>' + full_name + '</span><br />');
					}
				});
			}
			else
			{
				$('#msg').html(employees.msg).effect('pulsate', null, 600, hideErrorMsg);
			}

			set_form_defaults('#hours_entry_form');
			set_form_defaults('#hours_entry_form_alt');
		}
		else if(ui.panel.id == 'tabs-employee-total')
		{
			//console.log('tabs-employee-total');
			
			$('#employees_container').hide();
			$('#entry_form').hide();
			$('#employee_totals').show();
			
			$('#employee_totals_table').find('tbody').empty();
			
			//$('#submit_employee_totals').click();
		}
	});
	$tab.tabs('select', 'tabs-add-employee');
	
	$('#employees_select').on('change', function(event)
	{
		clear_form('#employee_table');
		$('#travel_rate').val(employee_travel_rate);
		
		var employee = $(this).val();
		
		if(employee != '')
		{
			var employee = $.parseJSON(get_employees(employee, '', false));
			var active = employee.result[0].active;
			
			$('#employee_table').find(':input').not(':button').each(function(index)
			{
				var type = $(this).attr('type');
				var id = $(this).attr('id');
				var val = employee.result[0][id];
				
				if(type == 'checkbox')
				{
					if(id != 'delete_user')
					{
						var id = '#' + id + '_rate_row';
						
						if(val == 1)
						{
							$(this).prop('checked', true);
							$(id).show();
						}
						else if(val == 0)
						{
							$(this).prop('checked', false);
							$(id).hide();
						}
						
						$(this).val(val);
					}
					
					if(id == 'delete_user')
					{
						if(active == 1)
						{
							$(this).prop('checked', false);
							$(this).val(0);
						}
						else if(active == 0)
						{
							$(this).prop('checked', true);
							$(this).val(1);
						}
					}
				}
				else
				{
					$(this).val(val);
				}
			});
		}
		else
		{
			$('#employee_table').find('#id').val('');
			$('#employee_table').find('#mover, #driver').val(0);
			$('#mover_rate_row, #driver_rate_row').hide();
		}
	});
	
	$('#employee_table').find('#submit').click(function()
	{
		var delete_user = $('#delete_user').prop('checked');
		var employee_data = {};
		
		$('#employee_table').find(':input').not('#delete_user, :button').each(function(index)
		{
			employee_data[$(this).attr('id')] = $(this).val();
		});
		
		$.ajax({
			type: 'POST',
			url: 'index.php/home/insert_employee',
			data:
			{
				employee_data : employee_data,
				delete_user : delete_user
			},
			dataType: 'json',
			success: function(data)
			{
				scrollToTop();
				
				if(data.success)
				{
					refresh_employee_dropdown();
					clear_form('#employee_table');
					$('#employee_table').find('#id').val('');
					$('#mover_rate_row, #driver_rate_row').hide();
					$('#travel_rate').val(employee_travel_rate);
					$('#employee_table').find('input[type=checkbox]').val(0);
					$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
				}
				else
				{
					$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
				}
			}
		});
		
	});
	
	$('#employee_table').find('#delete').click(function()
	{
		$("#delete_dialog").dialog({
			resizable: false,
			width: 400,
			height: 140,
			modal: true,
			draggable: false,
			title: 'Delete employee?',
			buttons:
			{
				'Delete': function()
				{
					var user_id = $('#employee_table').find('#id').val();
					
					if(user_id != '')
					{
						var data = $.parseJSON(delete_employee(user_id));
						
						if(data.success)
						{
							refresh_employee_dropdown();
							clear_form('#employee_table');
							$('#employee_table').find('#id').val('');
							$('#mover_rate_row, #driver_rate_row').hide();
							$('#travel_rate').val(employee_travel_rate);
							$('#employee_table').find('input[type=checkbox]').val(0);
							$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
						}
						else
						{
							$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
						}
					}
					
					$(this).dialog('close');
					scrollToTop();
				},
				Close: function()
				{
					$(this).dialog('close');
					scrollToTop();
				}
			}
		});
	});

	$('#hours_entry_form, #hours_entry_form_alt').on('click', 'button', function(event)
	{
		var datepicker_entry_form = true;
		var work_entire_move_container = true;
		var truck_select = true;
		var msg = '';
		
		var btn_id = $(this).attr('id');
		
		if(btn_id == 'submit')
		{
			var hours_entry_form = '#hours_entry_form';
			var drivers_container = '#drivers_container';
			var movers_container = '#movers_container';
			var drivers_gratuity_container = '#driver_list';
			var movers_gratuity_container = '#mover_list';
		}
		else
		{
			var hours_entry_form = '#hours_entry_form_alt';
			var drivers_container = '#drivers_container_alt';
			var movers_container = '#movers_container_alt';
			var drivers_gratuity_container = '#driver_list_alt';
			var movers_gratuity_container = '#mover_list_alt';
		}
		
		if($('#datepicker_entry_form').val() == '')
		{
			datepicker_entry_form = false;
			msg = 'Please select a date';
		}
		/*
		if(($('#work_entire_move_container').is(':hidden')))
		{
			work_entire_move_container = false;
			msg = 'Please select movers/drivers';
		}
		*/
		if($('#truck_select').val() == '')
		{
			truck_select = false;
			msg = 'Please select a truck';
		}
		
		if(datepicker_entry_form && work_entire_move_container && truck_select)
		{
			var employees_time = {};
			var checkboxes_drivers = {};
			var checkboxes_movers = {};
			var gratuity_drivers = [];
			var gratuity_movers = [];
			
			$(hours_entry_form).find('[name="display"]').each(function(index)
			{
				var id = $(this).attr('id');
				var id_new = id.replace(/_alt/i, "");
				employees_time[id_new] = $(this).text();
			});
			
			$(drivers_container).find('input[type=checkbox]').filter(':checked').each(function(index, value)
			{
				var id = $(this).attr('id');
				checkboxes_drivers[index] = $('#'+id).val();
			});
			
			$(movers_container).find('input[type=checkbox]').filter(':checked').each(function(index, value)
			{
				var id = $(this).attr('id');
				checkboxes_movers[index] = $('#'+id).val();
			});
			
			$(drivers_gratuity_container).find('[name="gratuity"]').each(function(index)
			{
				gratuity_drivers[index] = $(this).val();
			});
			
			$(movers_gratuity_container).find('[name="gratuity"]').each(function(index)
			{
				gratuity_movers[index] = $(this).val();
			});

			$.ajax({
				type: 'POST',
				url: 'index.php/home/insert_employees_time',
				data:
				{
					datepicker : $('#datepicker_entry_form').val(),
					truck_select : $('#truck_select').val(),
					checkboxes_drivers : checkboxes_drivers,
					checkboxes_movers : checkboxes_movers,
					employees_time : employees_time,
					gratuity_drivers : gratuity_drivers,
					gratuity_movers : gratuity_movers
				},
				dataType: 'json',
				success: function(data)
				{
					scrollToTop();
					
					if(data.success)
					{
						if(btn_id == 'submit')
						{
							clear_form('#entry_form_left');
							clear_form('#hours_entry_form');
							$('#work_entire_move_yes').click();
							$('#driver_list, #mover_list').empty();
							set_form_defaults('#hours_entry_form');
						}
						else
						{
							clear_form('#hours_entry_form_alt');
							$('#work_entire_move_yes').click();
							$('#driver_list_alt, #mover_list_alt').empty();
							set_form_defaults('#hours_entry_form_alt');
						}
						
						$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
					}
					else
					{
						$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
					}
				}
			});
		}
		else
		{
			scrollToTop();
			$('#msg').html(msg).effect('pulsate', null, 600, hideErrorMsg);
		}
	});
	
	$('#submit_employee_totals').click(function(event)
	{
		var datepicker_selected_arr = get_employee_totals_dates();
		//console.log(datepicker_selected_arr);
		var data = $.parseJSON(get_employee_totals(datepicker_selected_arr[0], datepicker_selected_arr[1]));
		
		$('#employee_totals_table').find('tbody').empty();
		$('#employee_totals_table').find('tfoot').empty();
		
		if(data.success)
		{
			$.each(data.result.data, function(k, v)
			{
				$('#employee_totals_table').find('tbody').append('<tr id="row_' + k + '"></tr>');
				//$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.id + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.full_name + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_travel_hours_percent_display + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_move_hours_percent_display_mover + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_move_hours_percent_display_driver + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_ot_1_5x_hours_percent_display_mover + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_ot_1_5x_hours_percent_display_driver + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_ot_2x_hours_percent_display_mover + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>' + v.total_ot_2x_hours_percent_display_driver + '</td>');
				$('#employee_totals_table').find('tbody').find('#row_'+k).append('<td>$' + v.gratuity + '</td>');
			});
			
			$('#employee_totals_table').find('tfoot').append('<tr><td colspan="9">&nbsp;</td></tr><tr id="row_total"><td>Pay Period Total</td></tr>');
			
			$.each(data.result.total_count, function(k, v)
			{
				if(k === 'gratuity')
					v = '$' + v;
					
					$('#employee_totals_table').find('tfoot').find('#row_total').append('<td class="bold">' + v + '</td>');
			});
			
			//var oTable = $('#employee_totals_table').dataTable();
		}
		else
		{
			$('#employee_totals_table').find('tbody').append('<tr id="row_error"></tr>');
			$('#employee_totals_table').find('tbody').find('#row_error').append('<td colspan="9" align="center">' + data.msg + '</td>');
			
			//$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
		}
	});
	
	$('#employee_totals_date_select').on('change', function(event)
	{
		var selected = $(this).val();
		
		if(selected == 'custom')
		{
			$('#datepicker_employee_totals_container').show();
		}
		else
		{
			$('#datepicker_employee_totals_container').hide();
		}
	});
	
	$(document).on('click', '#drivers_container input[type=checkbox], #movers_container input[type=checkbox]', function(event)
	{
		// check if a driver was selected
		var checkboxes_drivers = $('#drivers_container').find('input[type=checkbox]');
		var checkboxes_movers = $('#movers_container').find('input[type=checkbox]');
		var checkboxes_drivers_alt = $('#drivers_container_alt').find('input[type=checkbox]');
		var checkboxes_movers_alt = $('#movers_container_alt').find('input[type=checkbox]');

		if(checkboxes_drivers.filter(':checked').length > 0 && checkboxes_movers.filter(':checked').length > 0)
		{
			refresh_alt_drivers_movers();
			show_work_entire_move_container(true);
		}
		else
		{
			show_work_entire_move_container(false);
			$('#entry_form_alt').hide();
		}
		
		refresh_driver_mover_display_names('#driver_list', '#mover_list', checkboxes_drivers, checkboxes_movers);
		refresh_driver_mover_display_names('#driver_list_alt', '#mover_list_alt', checkboxes_drivers_alt, checkboxes_movers_alt);
	});
	
	$(document).on('click', '#drivers_container_alt input[type=checkbox], #movers_container_alt input[type=checkbox]', function(event)
	{
		// check if a driver was selected
		var checkboxes_drivers = $('#drivers_container').find('input[type=checkbox]');
		var checkboxes_movers = $('#movers_container').find('input[type=checkbox]');
		var checkboxes_drivers_alt = $('#drivers_container_alt').find('input[type=checkbox]');
		var checkboxes_movers_alt = $('#movers_container_alt').find('input[type=checkbox]');
		
		refresh_driver_mover_display_names('#driver_list_alt', '#mover_list_alt', checkboxes_drivers_alt, checkboxes_movers_alt);
		refresh_driver_mover_display_names('#driver_list', '#mover_list', checkboxes_drivers, checkboxes_movers);
	});
	
	$(document).on('change', '#work_entire_move_container input[type=radio]', function(event)
	{
		refresh_alt_drivers_movers($(this));
	});
	
	$('#hours_entry_form input, #hours_entry_form select').on('keyup change', function(event)
	{
		var obj = $(this);
		var parent_tr = $(obj).parents('tr');
		
		if(!isNaN($(obj).val()) || $(obj).val() == 'am' || $(obj).val() == 'pm' || $(obj).val() == 'am_next_day')
		{
			// displays the time under the TIME column
			display_time(parent_tr, obj);
			
			// calculates the total number of hours/minutes for the travel hours
			calc_total_travel_hours();
			
			// calculates the total number of hours/minutes for the move hours
			calc_total_move_hours();

			// calculates the percentage for travel hours out of the total
			calc_travel_hours_percent();
			
			// calculates the percentage for move hours out of the total
			calc_move_hours_percent();
			
			// calculates the total travel + move hours
			calc_total_hours();
			
			// calculates the number of regular, 1.5x OT, 2x OT
			calc_regular_ot_pay_move_hours_percent();
		}
	});
	
	$('#hours_entry_form_alt input, #hours_entry_form_alt select').on('keyup change', function(event)
	{
		var obj = $(this);
		var parent_tr = $(obj).parents('tr');
		
		if(!isNaN($(obj).val()) || $(obj).val() == 'am' || $(obj).val() == 'pm' || $(obj).val() == 'am_next_day')
		{
			// displays the time under the TIME column
			display_time(parent_tr, obj);
			
			// calculates the total number of hours/minutes for the travel hours
			calc_total_travel_hours_alt();
			
			// calculates the total number of hours/minutes for the move hours
			calc_total_move_hours_alt();

			// calculates the percentage for travel hours out of the total
			calc_travel_hours_percent_alt();
			
			// calculates the percentage for move hours out of the total
			calc_move_hours_percent_alt();
			
			// calculates the total travel + move hours
			calc_total_hours_alt();
			
			// calculates the number of regular, 1.5x OT, 2x OT
			calc_regular_ot_pay_move_hours_percent_alt();
		}
	});
	
	$('#employee_totals_detail_table input, #employee_totals_detail_table select[name="am_pm"]').live("keyup change", function(event)
	//$('#employee_totals_detail_table input, #employee_totals_detail_table select').on('keyup change', function(event)
	{
		var obj = $(this);
		var parent_tr = $(obj).parents('tr');
		var et_id = parent_tr.attr('id').split("-");
		
		if(!isNaN($(obj).val()) || $(obj).val() == 'am' || $(obj).val() == 'pm' || $(obj).val() == 'am_next_day')
		{
			// displays the time under the TIME column
			display_time(parent_tr, obj);
			
			// calculates the total number of hours/minutes for the travel hours
			calc_total_travel_hours_details(et_id[1]);
			
			// calculates the total number of hours/minutes for the move hours
			calc_total_move_hours_details(et_id[1]);
			
			// calculates the percentage for travel hours out of the total
			calc_travel_hours_percent_details(et_id[1]);
			
			// calculates the percentage for move hours out of the total
			calc_move_hours_percent_details(et_id[1]);
			
			// calculates the total travel + move hours
			calc_total_hours_details();
			
			// calculates the number of regular, 1.5x OT, 2x OT
			calc_regular_ot_pay_move_hours_percent_details(et_id[1]);
		}
	});
	
	$('#export_csv').click(function(event)
	{
		event.preventDefault();
		
		var date = get_employee_totals_dates();
		var startDate = date[0].replace(/\//g, "_");
		var endDate = date[1].replace(/\//g, "_");
		
		$('#report_loader').attr('src', 'index.php/export/index/type/csv/startDate/' + startDate + '/endDate/' + endDate);
	});
	
	$(document).on('click', 'input[type=checkbox]', function(event)
	//$('#employee_table').find('input[type=checkbox]').click(function()
	{
		var parent_container = $(this).parent('div').attr('id');
		var arr = ['drivers_container', 'movers_container', 'drivers_container_alt', 'movers_container_alt'];
		
		if(jQuery.inArray(parent_container, arr) == -1)
		{
			var id = '#' + $(this).attr('id') + '_rate_row';
			
			if($(this).prop('checked'))
			{
				$(this).val(1);
				$(id).show();
				
				if($(this).attr('id') == 'employee_totals_detail_editable')
				{
					disable_inputs('#employee_totals_detail_table', false);
				}
			}
			else
			{
				$(this).val(0);
				$(id).hide();
				
				if($(this).attr('id') == 'employee_totals_detail_editable')
				{
					disable_inputs('#employee_totals_detail_table', true);
				}
			}
		}
	});
	
	$('#employee_totals_table').on('click', 'tr', function(event)
	{
		var arr = {};
		var id = $(this).attr('id').split("_");
		var full_name = $(this).find('td').first().text();
		var datepicker_selected_arr = get_employee_totals_dates();
		var data = $.parseJSON(get_employee_totals_detail(id[1], datepicker_selected_arr[0], datepicker_selected_arr[1]));
		
		$('#employee_totals_detail_editable_container').empty();
		$('#preview_dialog_text').prepend('<div id="employee_totals_detail_editable_container"><input type="checkbox" id="employee_totals_detail_editable" name="employee_totals_detail_editable" value="0" />editable</div>');
		$('#employee_totals_detail_table').find('thead, tbody, foot').remove();
		
		if(data.success)
		{
			$.ajax({
				type: 'POST',
				url: 'index.php/home/employee_details_template',
				async: true,
				data:
				{
					
				},
				dataType: 'json',
				success: function(data2)
				{
					var template = data2.content;
					
					$.each(data.result, function(k, v)
					{
						var text = template;
						
						var et_id = v.et_id;
						var emp_id = v.emp_id;
						var truck = v.truck;
						var time_in_display = v.time_in_display.split(":");
						var first_move_start_display = v.first_move_start_display.split(":");
						var first_move_end_display = v.first_move_end_display.split(":");
						var lunch_start_display = v.lunch_start_display.split(":");
						var lunch_end_display = v.lunch_end_display.split(":");
						var second_move_start_display = v.second_move_start_display.split(":");
						var second_move_end_display = v.second_move_end_display.split(":");
						var time_out_display = v.time_out_display.split(":");
						
						var total_travel_hours_display = v.total_travel_hours_display.split(":");
						var total_move_hours_display = v.total_move_hours_display.split(":");
						var total_travel_hours_percent_display = v.total_travel_hours_percent_display.split(":");
						var total_move_hours_percent_display = v.total_move_hours_percent_display.split(":");
						var total_pay_move_hours_percent_display = v.total_pay_move_hours_percent_display.split(":");
						var total_ot_1_5x_hours_percent_display_mover = v.total_ot_1_5x_hours_percent_display_mover.split(":");
						var total_ot_1_5x_hours_percent_display_driver = v.total_ot_1_5x_hours_percent_display_driver.split(":");
						var total_ot_2x_hours_percent_display_mover = v.total_ot_2x_hours_percent_display_mover.split(":");
						var total_ot_2x_hours_percent_display_driver = v.total_ot_2x_hours_percent_display_driver.split(":");
						
						var gratuity = v.gratuity;
						
						if(time_in_display[0] >= 12)
						{
							text = text.replace(/{time_in_display_am}/g, '');
							text = text.replace(/{time_in_display_pm}/g, 'selected="selected"');

							var time_in_display_text = military_to_am_pm(time_in_display[0]) + ":" + time_in_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{time_in_display_am}/g, 'selected="selected"');
							text = text.replace(/{time_in_display_pm}/g, '');

							var time_in_display_text = military_to_am_pm(time_in_display[0]) + ":" + time_in_display[1] + " am";
						}
						
						if(first_move_start_display[0] >= 12)
						{
							text = text.replace(/{first_move_start_am}/g, '');
							text = text.replace(/{first_move_start_pm}/g, 'selected="selected"');

							var first_move_start_display_text = military_to_am_pm(first_move_start_display[0]) + ":" + first_move_start_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{first_move_start_am}/g, 'selected="selected"');
							text = text.replace(/{first_move_start_pm}/g, '');

							var first_move_start_display_text = military_to_am_pm(first_move_start_display[0]) + ":" + first_move_start_display[1] + " am";
						}
						
						if(first_move_end_display[0] >= 12)
						{
							text = text.replace(/{first_move_end_am}/g, '');
							text = text.replace(/{first_move_end_pm}/g, 'selected="selected"');

							var first_move_end_display_text = military_to_am_pm(first_move_end_display[0]) + ":" + first_move_end_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{first_move_end_am}/g, 'selected="selected"');
							text = text.replace(/{first_move_end_pm}/g, '');
							
							var first_move_end_display_text = military_to_am_pm(first_move_end_display[0]) + ":" + first_move_end_display[1] + " am";
						}
						
						if(lunch_start_display[0] >= 12)
						{
							text = text.replace(/{lunch_start_am}/g, '');
							text = text.replace(/{lunch_start_pm}/g, 'selected="selected"');

							var lunch_start_display_text = military_to_am_pm(lunch_start_display[0]) + ":" + lunch_start_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{lunch_start_am}/g, 'selected="selected"');
							text = text.replace(/{lunch_start_pm}/g, '');

							var lunch_start_display_text = military_to_am_pm(lunch_start_display[0]) + ":" + lunch_start_display[1] + " am";
						}
						
						if(lunch_end_display[0] >= 12)
						{
							text = text.replace(/{lunch_end_am}/g, '');
							text = text.replace(/{lunch_end_pm}/g, 'selected="selected"');
							
							var lunch_end_display_text = military_to_am_pm(lunch_end_display[0]) + ":" + lunch_end_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{lunch_end_am}/g, 'selected="selected"');
							text = text.replace(/{lunch_end_pm}/g, '');

							var lunch_end_display_text = military_to_am_pm(lunch_end_display[0]) + ":" + lunch_end_display[1] + " am";
						}
						
						if(second_move_start_display[0] >= 12)
						{
							text = text.replace(/{second_move_start_am}/g, '');
							text = text.replace(/{second_move_start_pm}/g, 'selected="selected"');

							var second_move_start_display_text = military_to_am_pm(second_move_start_display[0]) + ":" + second_move_start_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{second_move_start_am}/g, 'selected="selected"');
							text = text.replace(/{second_move_start_pm}/g, '');

							var second_move_start_display_text = military_to_am_pm(second_move_start_display[0]) + ":" + second_move_start_display[1] + " am";
						}
						
						if(second_move_end_display[0] >= 12)
						{
							text = text.replace(/{second_move_end_am}/g, '');
							text = text.replace(/{second_move_end_pm}/g, 'selected="selected"');

							var second_move_end_display_text = military_to_am_pm(second_move_end_display[0]) + ":" + second_move_end_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{second_move_end_am}/g, 'selected="selected"');
							text = text.replace(/{second_move_end_pm}/g, '');

							var second_move_end_display_text = military_to_am_pm(second_move_end_display[0]) + ":" + second_move_end_display[1] + " am";
						}
						
						if(time_out_display[0] >= 12)
						{
							text = text.replace(/{time_out_am}/g, '');
							text = text.replace(/{time_out_pm}/g, 'selected="selected"');

							var time_out_display_text = military_to_am_pm(time_out_display[0]) + ":" + time_out_display[1] + " pm";
						}
						else
						{
							text = text.replace(/{time_out_am}/g, 'selected="selected"');
							text = text.replace(/{time_out_pm}/g, '');

							var time_out_display_text = military_to_am_pm(time_out_display[0]) + ":" + time_out_display[1] + " am";
						}
						
						text = text.replace(/{date}/g, v.date);
						
						text = text.replace(/{id}/g, v.et_id);

						text = text.replace(/{time_in_hours}/g, military_to_am_pm(time_in_display[0]));
						text = text.replace(/{time_in_minutes}/g, time_in_display[1]);
						text = text.replace(/{time_in_details_display}/g, time_in_display_text);
						
						text = text.replace(/{first_move_start_hours}/g, military_to_am_pm(first_move_start_display[0]));
						text = text.replace(/{first_move_start_minutes}/g, first_move_start_display[1]);
						text = text.replace(/{first_move_start_details_display}/g, first_move_start_display_text);
						
						text = text.replace(/{first_move_end_hours}/g, military_to_am_pm(first_move_end_display[0]));
						text = text.replace(/{first_move_end_minutes}/g, first_move_end_display[1]);
						text = text.replace(/{first_move_end_details_display}/g, first_move_end_display_text);
						
						text = text.replace(/{lunch_start_hours}/g, military_to_am_pm(lunch_start_display[0]));
						text = text.replace(/{lunch_start_minutes}/g, lunch_start_display[1]);
						text = text.replace(/{lunch_start_details_display}/g, lunch_start_display_text);
						
						text = text.replace(/{lunch_end_hours}/g, military_to_am_pm(lunch_end_display[0]));
						text = text.replace(/{lunch_end_minutes}/g, lunch_end_display[1]);
						text = text.replace(/{lunch_end_details_display}/g, lunch_end_display_text);

						text = text.replace(/{second_move_start_hours}/g, military_to_am_pm(second_move_start_display[0]));
						text = text.replace(/{second_move_start_minutes}/g, second_move_start_display[1]);
						text = text.replace(/{second_move_start_details_display}/g, second_move_start_display_text);

						text = text.replace(/{second_move_end_hours}/g, military_to_am_pm(second_move_end_display[0]));
						text = text.replace(/{second_move_end_minutes}/g, second_move_end_display[1]);
						text = text.replace(/{second_move_end_details_display}/g, second_move_end_display_text);
						
						text = text.replace(/{time_out_hours}/g, military_to_am_pm(time_out_display[0]));
						text = text.replace(/{time_out_minutes}/g, time_out_display[1]);
						text = text.replace(/{time_out_details_display}/g, time_out_display_text);
						
						//text = text.replace(/{gratuity}/g, v.gratuity);

						$('#employee_totals_detail_table').append(text);
						
						$('#employee_totals_detail_table').find('thead [id="truck-'+et_id+'"]').val(truck);
						
						// calculates the total number of hours/minutes for the travel hours
						calc_total_travel_hours_details(v.et_id);
						
						// calculates the total number of hours/minutes for the move hours
						calc_total_move_hours_details(v.et_id);
						
						// calculates the percentage for travel hours out of the total
						calc_travel_hours_percent_details(v.et_id);
						
						// calculates the percentage for move hours out of the total
						calc_move_hours_percent_details(v.et_id);
						
						// calculates the total travel + move hours
						calc_total_hours_details();
						
						// calculates the number of regular, 1.5x OT, 2x OT
						calc_regular_ot_pay_move_hours_percent_details(v.et_id);

						$('#gratuity_details_display-'+et_id).text('$' + v.gratuity);
					});
					
					disable_inputs('#employee_totals_detail_table', true);
				}
			});
			
			$("#preview_dialog").dialog({
				resizable: false,
				width: 485,
				height: 800,
				modal: true,
				draggable: false,
				title: 'Employee Totals Detail - '+full_name,
				buttons:
				{
					'Save': function()
					{
						var arr = new Array();
						
						$('#employee_totals_detail_table').find('thead select').each(function(index)
						{
							var input_row_id = $(this).attr('id').split("-");
							var id = input_row_id[1];
							var select_val = $(this).val();
							
							arr.push({ 'id': id, 'col_name': input_row_id[0], 'col_val': select_val });
						});
						
						$('#employee_totals_detail_table').find('tbody tr').each(function(index)
						{
							var input_row_id = $(this).attr('id').split("-");
							var id = input_row_id[1];
							
							var display_val = $(this).find('td [name="display"]').text();
							
							if(display_val == '')
							{
								var display_val = $(this).find('td[name="display"]').text();
							}
							
							arr.push({ 'id': id, 'col_name': input_row_id[0]+'_display', 'col_val': display_val });
						});
						
						//console.log(arr);
						var data = $.parseJSON(save_employee_details(arr));
						
						if(data.success)
						{
							$('#submit_employee_totals').click();
							$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
						}
						else
						{
							$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
						}
						
						$(this).dialog('close');
						scrollToTop();
					},
					Close: function()
					{
						$(this).dialog('close');
						scrollToTop();
					}
				}
			});
		}
		
		scrollToTop();
	});
	
	$('#employee_totals_detail_table').on('click', 'button', function(event)
	{
		var input_row_id = $(this).attr('id').split("-");
		var id = input_row_id[1];
		var date = $(this).val();
		
		$('#delete_dialog_text').html('Are you sure you want to delete this day ('+date+')?');
		
		$("#delete_dialog").dialog({
			resizable: false,
			width: 400,
			height: 140,
			modal: true,
			draggable: false,
			title: '',
			buttons:
			{
				'Delete': function()
				{
					var data = $.parseJSON(delete_employee_details(id));
					
					if(data.success)
					{
						$('#submit_employee_totals').click();
						$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
						
						$('#employee_totals_detail_table').find('#thead-'+id).remove();
						$('#employee_totals_detail_table').find('#tbody-'+id).remove();
						$('#employee_totals_detail_table').find('#tfoot-'+id).remove();
					}
					else
					{
						$('#msg').html(data.msg).effect('pulsate', null, 600, hideErrorMsg);
					}
					
					$(this).dialog('close');
					scrollToTop();
				},
				Close: function()
				{
					$(this).dialog('close');
					scrollToTop();
				}
			}
		});
	});
	
	function disable_inputs(id, disabled)
	{
		$(id).find('input[type=text]').each(function(index)
		{
			if(disabled)
			{
				$(this).prop('readonly', true);
				$(this).css({'background-color' : '#e8e8e8'});
			}
			else
			{
				$(this).prop('readonly', false);
				$(this).css({'background-color' : ''});
			}
		});
		
		$(id).find('select').each(function(index)
		{
			if(disabled)
			{
				$(this).prop('disabled', true);
				$(this).css({'background-color' : '#e8e8e8'});
			}
			else
			{
				$(this).prop('disabled', false);
				$(this).css({'background-color' : ''});
			}
		});
		
		$(id).find('input[type=checkbox]').each(function(index)
		{
			if(disabled)
			{
				$(this).prop('disabled', true);
			}
			else
			{
				$(this).prop('disabled', false);
			}
		});
		
		$(id).find('button').each(function(index)
		{
			if(disabled)
			{
				$(this).prop('disabled', true);
			}
			else
			{
				$(this).prop('disabled', false);
			}
		});
	}
	
	function refresh_driver_mover_display_names(driver_id, mover_id, checkboxes_drivers, checkboxes_movers)
	{
		$(driver_id).empty();
		$(mover_id).empty();
		
		// list drivers above the first form
		$.each(checkboxes_drivers.filter(':checked'), function(index, value)
		{
			var id = $(this).attr('id');
			var full_name = $(this).next('span').text() + '&nbsp;Gratuity: <input type="text" id="gratuity" name="gratuity"><br />';
			$(driver_id).append(full_name);

			if(driver_id == '#driver_list_alt')
			{
				id = id.replace('alt_', '');
				$('#' + id).prop('checked', false);
			}
		});
		
		// list movers above the first form
		$.each(checkboxes_movers.filter(':checked'), function(index, value)
		{
			var id = $(this).attr('id');
			var full_name = $(this).next('span').text() + '&nbsp;Gratuity: <input type="text" id="gratuity" name="gratuity"><br />';
			$(mover_id).append(full_name);
			
			if(mover_id == '#mover_list_alt')
			{
				id = id.replace('alt_', '');
				$('#' + id).prop('checked', false);
			}
		});
	}
	
	function refresh_employee_dropdown()
	{
		var employees = $.parseJSON(get_employees('', '', false));
		
		$('#employees_select').empty();
		
		$('#employees_select').append('<option value="" selected="selected">Add Employee</option>');
		$.each(employees.result, function(index, value)
		{
			var full_name = value.first_name + ' ' + value.last_name
			
			if(value.active == 1)
			{
				var active = '(A)';
			}
			else
			{
				var active = '(I)';
			}
			
			$('#employees_select').append('<option value="' + value.id + '">' + full_name + ' ' + active + '</option>');
		});
	}
	
	function refresh_alt_drivers_movers(obj)
	{
		if(obj == undefined)
		{
			var obj = $('#work_entire_move_container input[type=radio]:checked');
		}
		
		if(obj.val() == 0)
		{
			$('#drivers_container_alt, #movers_container_alt').empty();
			
			$('#drivers_container').find('input[type=checkbox]:checked').each(function(index)
			{
				var id = $(this).attr('id').split('_');
				var val = $(this).val();
				var full_name = $(this).next().text();
				
				$('#drivers_container_alt').append('<input type="checkbox" id="drivers_alt_' + id[1] + '" name="drivers_alt" value="' + id[1] + '" /><span>' + full_name + '</span><br />');
			});
			
			$('#movers_container').find('input[type=checkbox]:checked').each(function(index)
			{
				var id = $(this).attr('id').split('_');
				var val = $(this).val();
				var full_name = $(this).next().text();
				
				$('#movers_container_alt').append('<input type="checkbox" id="movers_alt_' + id[1] + '" name="movers_alt" value="' + id[1] + '" /><span>' + full_name + '</span><br />');
			});
			
			$('#entry_form_alt, #drivers_movers_container_alt').show();
			
			set_form_defaults('#hours_entry_form_alt');
		}
		else
		{
			clear_form('#hours_entry_form_alt');
			$('#entry_form_alt, #drivers_movers_container_alt').hide();
		}
	}
	
	function set_form_defaults(id)
	{
		if(id == '#hours_entry_form')
		{
			$('#work_entire_move_container').hide();

			$('#tabs-entry-form').find('#driver_list').empty();
			$('#tabs-entry-form').find('#mover_list').empty();

			$('#work_entire_move_yes').click();
			$('#datepicker_entry_form').datepicker('setDate', '');
			$('#truck_select').val('');
		}
		
		if(id == '#hours_entry_form' || id == '#hours_entry_form_alt')
		{
			var counter = 1;
			
			$('#tabs-entry-form').find('#driver_list_alt').empty();
			$('#tabs-entry-form').find('#mover_list_alt').empty();
			
			$(id).find('input[name="hours"]').each(function(index)
			{
				$(this).val('');
			});
			
			$(id).find('input[name="minutes"]').each(function(index)
			{
				$(this).val('00');
			});
			
			$(id).find('span[name="display"]').each(function(index)
			{
				$(this).html('');
			});
			
			$(id).find('span[name="total_hours"]').each(function(index)
			{
				$(this).html('0');
			});
			
			$(id).find('span[name="total_minutes"]').each(function(index)
			{
				$(this).html('0');
			});
			
			$(id).find('td[id^="total_travel_hours_percent_display"]').html('0.00');
			$(id).find('td[id^="total_move_hours_percent_display"]').html('0.00');
			$(id).find('td[id^="total_pay_move_hours_percent_display"]').html('0.00');
			$(id).find('td[id^="total_ot_1_5x_hours_percent_display"]').html('0.00');
			$(id).find('td[id^="total_ot_2x_hours_percent_display"]').html('0.00');

			$(id).find('select').each(function(index)
			{
				if(counter <= 2)
				{
					$(this).val('am');
				}
				else
				{
					$(this).val('pm');
				}
				
				counter++;
			});
		}
	}
	
	function get_employees(id, role, active)
	{
		var ajax = $.ajax({
			type: 'POST',
			url: 'index.php/home/get_employees',
			async: false,
			data:
			{
				id : id,
				role : role,
				active : active
			},
			dataType: 'json'
		}).responseText;
		
		return ajax;
	}
	
	function get_employee_totals(datepicker_start, datepicker_end)
	{
		var ajax = $.ajax({
			type: 'POST',
			url: 'index.php/home/get_employee_totals',
			async: false,
			data:
			{
				datepicker_start : datepicker_start,
				datepicker_end : datepicker_end
			},
			dataType: 'json'
		}).responseText;
		
		return ajax;
	}
	
	function get_employee_totals_detail(id, datepicker_start, datepicker_end)
	{
		var ajax = $.ajax({
			type: 'POST',
			url: 'index.php/home/get_employee_totals_detail',
			async: false,
			data:
			{
				id : id,
				datepicker_start : datepicker_start,
				datepicker_end : datepicker_end
			},
			dataType: 'json'
		}).responseText;
		
		return ajax;
	}
	
	function save_employee_details(data)
	{
		var ajax = $.ajax({
			type: 'POST',
			url: 'index.php/home/save_employee_details',
			async: false,
			data:
			{
				data : data
			},
			dataType: 'json'
		}).responseText;
		
		return ajax;
	}
	
	function delete_employee_details(id)
	{
		var ajax = $.ajax({
			type: 'POST',
			url: 'index.php/home/delete_employee_details',
			async: false,
			data:
			{
				id : id
			},
			dataType: 'json'
		}).responseText;
		
		return ajax;
	}
	
	function delete_employee(user_id)
	{
		var ajax = $.ajax({
			type: 'POST',
			url: 'index.php/home/delete_employee',
			async: false,
			data:
			{
				user_id : user_id
			},
			dataType: 'json'
		}).responseText;

		return ajax;
	}
	
	function get_employee_totals_dates()
	{
		var datepicker_start = getDateEmployeeTotalsStart();
		var datepicker_end = getDateEmployeeTotalsEnd();
		
		return new Array(datepicker_start, datepicker_end);
	}
});


/*
Helper functions
*/

function hideErrorMsg()
{
	$(this).hide();
}

function getDateEntryForm()
{
	return $('#datepicker_entry_form').val();
}

function getDateEmployeeTotalsStart()
{
	return $('#datepicker_employee_totals_start').val();
}

function getDateEmployeeTotalsEnd()
{
	return $('#datepicker_employee_totals_end').val();
}

function display_time(parent_tr, obj)
{
	var display = $(parent_tr).find($('[name="display"]'));
	var h = $(parent_tr).find($('input[name="hours"]')).val();
	var m = $(parent_tr).find($('input[name="minutes"]')).val();
	var am_pm = $(parent_tr).find($('select[name="am_pm"]')).val();
	
	if(h == '' && m == '')
	{
		$(display).empty();
	}
	else
	{
		$(display).html(h + ':' + pad(m, 2) + ' ' + am_pm);
	}
}

function is_empty(obj)
{
    if (typeof obj == 'undefined' || obj === null || obj === '' || obj == 0) return true;
    if (typeof obj == 'number' && isNaN(obj)) return true;
    if (obj instanceof Date && isNaN(Number(obj))) return true;
    return false;
}

function calc_total_travel_hours()
{
	travel_diff_in_minutes = 0;
	
	if(!is_empty($('#time_in_hours').val()) && !is_empty($('#first_move_start_hours').val()))
	{
		travel_diff_in_minutes = timeDiff($('#time_in_display').text(), $('#first_move_start_display').text());
	}

	if(!is_empty($('#first_move_end_hours').val()) && !is_empty($('#lunch_start_hours').val()))
	{
		travel_diff_in_minutes += timeDiff($('#first_move_end_display').text(), $('#lunch_start_display').text());
	}
	
	if(!is_empty($('#lunch_end_hours').val()) && !is_empty($('#second_move_start_hours').val()))
	{
		travel_diff_in_minutes += timeDiff($('#lunch_end_display').text(), $('#second_move_start_display').text());
	}
	
	if(!is_empty($('#second_move_end_hours').val()) && !is_empty($('#time_out_hours').val()))
	{
		travel_diff_in_minutes += timeDiff($('#second_move_end_display').text(), $('#time_out_display').text());
	}
	
	total_hours = Math.floor(travel_diff_in_minutes/60);
	total_minutes = Math.round(travel_diff_in_minutes - total_hours*60);

	$('#total_travel_hours_display').find('[name="total_hours"]').text(total_hours);
	$('#total_travel_hours_display').find('[name="total_minutes"]').text(total_minutes);
}

function calc_total_travel_hours_alt()
{
	travel_diff_in_minutes_alt = 0;
	
	if(!is_empty($('#time_in_hours_alt').val()) && !is_empty($('#first_move_start_hours_alt').val()))
	{
		travel_diff_in_minutes_alt = timeDiff($('#time_in_display_alt').text(), $('#first_move_start_display_alt').text());
	}

	if(!is_empty($('#first_move_end_hours_alt').val()) && !is_empty($('#lunch_start_hours_alt').val()))
	{
		travel_diff_in_minutes_alt += timeDiff($('#first_move_end_display_alt').text(), $('#lunch_start_display_alt').text());
	}
	
	if(!is_empty($('#lunch_end_hours_alt').val()) && !is_empty($('#second_move_start_hours_alt').val()))
	{
		travel_diff_in_minutes_alt += timeDiff($('#lunch_end_display_alt').text(), $('#second_move_start_display_alt').text());
	}
	
	if(!is_empty($('#second_move_end_hours_alt').val()) && !is_empty($('#time_out_hours_alt').val()))
	{
		travel_diff_in_minutes_alt += timeDiff($('#second_move_end_display_alt').text(), $('#time_out_display_alt').text());
	}
	
	total_hours = Math.floor(travel_diff_in_minutes_alt/60);
	total_minutes = Math.round(travel_diff_in_minutes_alt - total_hours*60);
	
	$('#total_travel_hours_display_alt').find('[name="total_hours"]').text(total_hours);
	$('#total_travel_hours_display_alt').find('[name="total_minutes"]').text(total_minutes);
}

function calc_total_travel_hours_details(et_id)
{
	travel_diff_in_minutes_details = 0;
	
	if(!is_empty($('#time_in_hours_details-'+et_id).val()) && !is_empty($('#first_move_start_hours_details-'+et_id).val()))
	{
		travel_diff_in_minutes_details = timeDiff($('#time_in_details_display-'+et_id).text(), $('#first_move_start_details_display-'+et_id).text());
		//console.log($('#time_in_details_display-'+et_id).text());
		//console.log($('#first_move_start_details_display-'+et_id).text());
		//console.log(travel_diff_in_minutes_details);
	}
	
	if(!is_empty($('#first_move_end_hours_details-'+et_id).val()) && !is_empty($('#lunch_start_hours_details-'+et_id).val()))
	{
		travel_diff_in_minutes_details += timeDiff($('#first_move_end_details_display-'+et_id).text(), $('#lunch_start_details_display-'+et_id).text());
		//console.log($('#first_move_end_details_display-'+et_id).text());
		//console.log($('#lunch_start_details_display-'+et_id).text());
		//console.log(travel_diff_in_minutes_details);
	}
	
	if(!is_empty($('#lunch_end_hours_details-'+et_id).val()) && !is_empty($('#second_move_start_hours_details-'+et_id).val()))
	{
		travel_diff_in_minutes_details += timeDiff($('#lunch_end_details_display-'+et_id).text(), $('#second_move_start_details_display-'+et_id).text());
		//console.log($('#lunch_end_details_display-'+et_id).text());
		//console.log($('#second_move_start_details_display-'+et_id).text());
		//console.log(travel_diff_in_minutes_details);
	}
	
	if(!is_empty($('#second_move_end_hours_details-'+et_id).val()) && !is_empty($('#time_out_hours_details-'+et_id).val()))
	{
		travel_diff_in_minutes_details += timeDiff($('#second_move_end_details_display-'+et_id).text(), $('#time_out_details_display-'+et_id).text());
		//console.log($('#second_move_end_details_display-'+et_id).text());
		//console.log($('#time_out_details_display-'+et_id).text());
		//console.log(travel_diff_in_minutes_details);
	}
	
	total_hours = Math.floor(travel_diff_in_minutes_details/60);
	total_minutes = Math.round(travel_diff_in_minutes_details - total_hours*60);
	
	$('#total_travel_hours_details_display-'+et_id).find('[name="total_hours"]').text(total_hours);
	$('#total_travel_hours_details_display-'+et_id).find('[name="total_minutes"]').text(total_minutes);
}

function calc_total_move_hours()
{
	var show_num = false;
	
	if
		(
			$('#first_move_start_hours').val() != '' && $('#first_move_start_minutes').val() != '' && 
			$('#first_move_end_hours').val() != '' && $('#first_move_end_minutes').val() != ''
		)
	{
		move_diff_in_minutes = timeDiff($('#first_move_start_display').text(), $('#first_move_end_display').text());
		show_num = true;
	}
	
	if
		(
			$('#second_move_start_hours').val() != '' && $('#second_move_start_minutes').val() != '' &&
			$('#second_move_end_hours').val() != '' && $('#second_move_end_minutes').val() != ''
		)
	{
		move_diff_in_minutes += timeDiff($('#second_move_start_display').text(), $('#second_move_end_display').text());
		show_num = true;
	}
	
	if(show_num)
	{
		total_hours = Math.floor(move_diff_in_minutes/60);
		total_minutes = Math.round(move_diff_in_minutes - total_hours*60);
		
		$('#total_move_hours_display').find('[name="total_hours"]').text(total_hours);
		$('#total_move_hours_display').find('[name="total_minutes"]').text(total_minutes);
	}
}

function calc_total_move_hours_alt()
{
	var show_num = false;
	
	if
		(
			$('#first_move_start_hours_alt').val() != '' && $('#first_move_start_minutes_alt').val() != '' && 
			$('#first_move_end_hours_alt').val() != '' && $('#first_move_end_minutes_alt').val() != ''
		)
	{
		move_diff_in_minutes_alt = timeDiff($('#first_move_start_display_alt').text(), $('#first_move_end_display_alt').text());
		show_num = true;
	}
	
	if
		(
			$('#second_move_start_hours_alt').val() != '' && $('#second_move_start_minutes_alt').val() != '' &&
			$('#second_move_end_hours_alt').val() != '' && $('#second_move_end_minutes_alt').val() != ''
		)
	{
		move_diff_in_minutes_alt += timeDiff($('#second_move_start_display_alt').text(), $('#second_move_end_display_alt').text());
		show_num = true;
	}
	
	if(show_num)
	{
		total_hours = Math.floor(move_diff_in_minutes_alt/60);
		total_minutes = Math.round(move_diff_in_minutes_alt - total_hours*60);
		
		$('#total_move_hours_display_alt').find('[name="total_hours"]').text(total_hours);
		$('#total_move_hours_display_alt').find('[name="total_minutes"]').text(total_minutes);
	}
}

function calc_total_move_hours_details(et_id)
{
	var show_num = false;
	
	if
		(
			$('#first_move_start_hours_details-'+et_id).val() != '' && $('#first_move_start_minutes_details-'+et_id).val() != '' && 
			$('#first_move_end_hours_details-'+et_id).val() != '' && $('#first_move_end_minutes_details-'+et_id).val() != ''
		)
	{
		move_diff_in_minutes_details = timeDiff($('#first_move_start_details_display-'+et_id).text(), $('#first_move_end_details_display-'+et_id).text());
		show_num = true;
	}
	
	if
		(
			$('#second_move_start_hours_details-'+et_id).val() != '' && $('#second_move_start_minutes_details-'+et_id).val() != '' &&
			$('#second_move_end_hours_details-'+et_id).val() != '' && $('#second_move_end_minutes_details-'+et_id).val() != ''
		)
	{
		move_diff_in_minutes_details += timeDiff($('#second_move_start_details_display-'+et_id).text(), $('#second_move_end_details_display-'+et_id).text());
		show_num = true;
	}
	
	if(show_num)
	{
		total_hours = Math.floor(move_diff_in_minutes_details/60);
		total_minutes = Math.round(move_diff_in_minutes_details - total_hours*60);
		
		$('#total_move_hours_details_display-'+et_id).find('[name="total_hours"]').text(total_hours);
		$('#total_move_hours_details_display-'+et_id).find('[name="total_minutes"]').text(total_minutes);
	}
}

function calc_travel_hours_percent()
{
	var travel_hours_percent = 0;
	
	if(typeof travel_diff_in_minutes != 'undefined' && typeof move_diff_in_minutes != 'undefined')
	{
		//if(travel_diff_in_minutes > 0 && move_diff_in_minutes > 0)
		//{
			//travel_hours_percent = Math.round(travel_diff_in_minutes/(travel_diff_in_minutes + move_diff_in_minutes)*1000)/1000;
			travel_hours_percent = (travel_diff_in_minutes/60).toFixed(2);
			$('#total_travel_hours_percent_display').text(travel_hours_percent);
		//}
	}
}

function calc_travel_hours_percent_alt()
{
	var travel_hours_percent = 0;
	
	if(typeof travel_diff_in_minutes_alt != 'undefined' && typeof move_diff_in_minutes_alt != 'undefined')
	{
		//if(travel_diff_in_minutes_alt > 0 && move_diff_in_minutes_alt > 0)
		//{
			//travel_hours_percent = Math.round(travel_diff_in_minutes/(travel_diff_in_minutes + move_diff_in_minutes)*1000)/1000;
			travel_hours_percent = (travel_diff_in_minutes_alt/60).toFixed(2);
			$('#total_travel_hours_percent_display_alt').text(travel_hours_percent);
		//}
	}
}

function calc_travel_hours_percent_details(et_id)
{
	var travel_hours_percent_details = 0;
	
	if(typeof travel_diff_in_minutes_details != 'undefined' && typeof move_diff_in_minutes_details != 'undefined')
	{
		//if(travel_diff_in_minutes_details > 0 && move_diff_in_minutes_details > 0)
		//{
			//travel_hours_percent = Math.round(travel_diff_in_minutes/(travel_diff_in_minutes + move_diff_in_minutes)*1000)/1000;
			travel_hours_percent_details = (travel_diff_in_minutes_details/60).toFixed(2);
			$('#total_travel_hours_percent_details_display-'+et_id).text(travel_hours_percent_details);
		//}
	}
}

function calc_move_hours_percent()
{
	var move_hours_percent = 0;
	
	if(typeof travel_diff_in_minutes != 'undefined' && typeof move_diff_in_minutes != 'undefined')
	{
		if(travel_diff_in_minutes > 0 && move_diff_in_minutes > 0)
		{
			//move_hours_percent = Math.round(move_diff_in_minutes/(travel_diff_in_minutes + move_diff_in_minutes)*1000)/1000;
			move_hours_percent = (move_diff_in_minutes/60).toFixed(2);
			$('#total_move_hours_percent_display').text(move_hours_percent);
		}
	}
}

function calc_move_hours_percent_alt()
{
	var move_hours_percent = 0;
	
	if(typeof travel_diff_in_minutes_alt != 'undefined' && typeof move_diff_in_minutes_alt != 'undefined')
	{
		if(travel_diff_in_minutes_alt > 0 && move_diff_in_minutes_alt > 0)
		{
			//move_hours_percent = Math.round(move_diff_in_minutes/(travel_diff_in_minutes + move_diff_in_minutes)*1000)/1000;
			move_hours_percent = (move_diff_in_minutes_alt/60).toFixed(2);
			$('#total_move_hours_percent_display_alt').text(move_hours_percent);
		}
	}
}

function calc_move_hours_percent_details(et_id)
{
	var move_hours_percent_details = 0;
	
	if(typeof travel_diff_in_minutes_details != 'undefined' && typeof move_diff_in_minutes_details != 'undefined')
	{
		if(travel_diff_in_minutes_details > 0 && move_diff_in_minutes_details > 0)
		{
			//move_hours_percent = Math.round(move_diff_in_minutes/(travel_diff_in_minutes + move_diff_in_minutes)*1000)/1000;
			move_hours_percent_details = (move_diff_in_minutes_details/60).toFixed(2);
			$('#total_move_hours_percent_details_display-'+et_id).text(move_hours_percent_details);
		}
	}
}

function calc_total_hours()
{
	total_hours_in_minutes = (travel_diff_in_minutes + move_diff_in_minutes);
}

function calc_total_hours_alt()
{
	total_hours_in_minutes_alt = (travel_diff_in_minutes_alt + move_diff_in_minutes_alt);
}

function calc_total_hours_details()
{
	total_hours_in_minutes_details = (travel_diff_in_minutes_details + move_diff_in_minutes_details);
}

function calc_regular_ot_pay_move_hours_percent()
{
	var regular = 0;
	var ot_1_5x = 0;
	var ot_2x = 0;
	
	if(move_diff_in_minutes <= 480)
	{
		regular = (move_diff_in_minutes/60);
		ot_1_5x = 0;
		ot_2x = 0;
	}
	else if(move_diff_in_minutes > 480 && move_diff_in_minutes < 720)
	{
		regular = (480/60);
		ot_1_5x = ((move_diff_in_minutes - 480)/60);
		ot_2x = 0;
	}
	else if(move_diff_in_minutes >= 720)
	{
		regular = (480/60);
		ot_1_5x = (240/60);
		ot_2x = ((move_diff_in_minutes - (480 + 240))/60);
	}
	
	$('#total_pay_move_hours_percent_display').text(regular.toFixed(2));
	$('#total_ot_1_5x_hours_percent_display').text(ot_1_5x.toFixed(2));
	$('#total_ot_2x_hours_percent_display').text(ot_2x.toFixed(2));
}

function calc_regular_ot_pay_move_hours_percent_alt()
{
	var regular = 0;
	var ot_1_5x = 0;
	var ot_2x = 0;
	
	if(move_diff_in_minutes_alt <= 480)
	{
		regular = (move_diff_in_minutes_alt/60);
		ot_1_5x = 0;
		ot_2x = 0;
	}
	else if(move_diff_in_minutes_alt > 480 && move_diff_in_minutes_alt < 720)
	{
		regular = (480/60);
		ot_1_5x = ((move_diff_in_minutes_alt - 480)/60);
		ot_2x = 0;
	}
	else if(move_diff_in_minutes_alt >= 720)
	{
		regular = (480/60);
		ot_1_5x = (240/60);
		ot_2x = ((move_diff_in_minutes_alt - (480 + 240))/60);
	}
	
	$('#total_pay_move_hours_percent_display_alt').text(regular.toFixed(2));
	$('#total_ot_1_5x_hours_percent_display_alt').text(ot_1_5x.toFixed(2));
	$('#total_ot_2x_hours_percent_display_alt').text(ot_2x.toFixed(2));
}

function calc_regular_ot_pay_move_hours_percent_details(et_id)
{
	var regular = 0;
	var ot_1_5x = 0;
	var ot_2x = 0;
	
	if(move_diff_in_minutes_details <= 480)
	{
		regular = (move_diff_in_minutes_details/60);
		ot_1_5x = 0;
		ot_2x = 0;
	}
	else if(move_diff_in_minutes_details > 480 && move_diff_in_minutes_details < 720)
	{
		regular = (480/60);
		ot_1_5x = ((move_diff_in_minutes_details - 480)/60);
		ot_2x = 0;
	}
	else if(move_diff_in_minutes_details >= 720)
	{
		regular = (480/60);
		ot_1_5x = (240/60);
		ot_2x = ((move_diff_in_minutes_details - (480 + 240))/60);
	}
	
	$('#total_pay_move_hours_percent_details_display-'+et_id).text(regular.toFixed(2));
	$('#total_ot_1_5x_hours_percent_details_display-'+et_id).text(ot_1_5x.toFixed(2));
	$('#total_ot_2x_hours_percent_details_display-'+et_id).text(ot_2x.toFixed(2));
}

function timeDiff(start_time, end_time)
{
	var diff_hours_in_minutes;
	var diff_minutes;
	var diff_in_minutes;
	
	var start_time_am_pm_split = start_time.split(" ");
	var start_time_split = start_time_am_pm_split[0].split(":");
	var start_time_hours = parseInt(start_time_split[0], 10);
	var start_time_minutes = parseInt(start_time_split[1], 10);
	
	var end_time_am_pm_split = end_time.split(" ");
	var end_time_split = end_time_am_pm_split[0].split(":");
	var end_time_hours = parseInt(end_time_split[0], 10);
	var end_time_minutes = parseInt(end_time_split[1], 10);
	
	if(start_time_am_pm_split[1] == 'pm' && start_time_hours != 12)
	{
		start_time_hours += 12;
	}
	
	if(end_time_am_pm_split[1] == 'pm' && end_time_hours != 12)
	{
		end_time_hours += 12;
	}
	
	if(start_time_am_pm_split[1] == 'am_next_day' && start_time_hours < 12)
	{
		start_time_hours += 24;
	}
	else if(start_time_am_pm_split[1] == 'am_next_day' && start_time_hours == 12)
	{
		start_time_hours += 12;
	}
	
	if(end_time_am_pm_split[1] == 'am_next_day' && end_time_hours < 12)
	{
		end_time_hours += 24;
	}
	else if(end_time_am_pm_split[1] == 'am_next_day' && end_time_hours == 12)
	{
		end_time_hours += 12;
	}
	
	if(start_time_hours > end_time_hours)
	{
		diff_hours_in_minutes = 0;
		diff_minutes = 0;
	}
	else if((start_time_hours == end_time_hours) && (start_time_minutes > end_time_minutes))
	{
		diff_hours_in_minutes = 0;
		diff_minutes = 0;
	}
	else
	{
		diff_hours_in_minutes = Math.abs(end_time_hours - start_time_hours)*60;
	}
	
	if(diff_minutes != 0)
	{
		diff_minutes = Math.abs(end_time_minutes - start_time_minutes);
	}
	
	if(start_time_minutes > end_time_minutes)
	{
		diff_in_minutes = Math.abs(diff_hours_in_minutes - diff_minutes);
	}
	else
	{
		diff_in_minutes = Math.abs(diff_hours_in_minutes + diff_minutes);
	}
	
	return diff_in_minutes;
}

function military_to_am_pm(hour)
{
	if(hour > 12)
	{
		var hour = (hour-12);
	}
	
	return pad(hour, 2);
}

function clear_form(ele)
{
	$(ele).find(':input').each(function()
	{
		switch(this.type)
		{
			case 'password':
			case 'select-multiple':
			case 'select-one':
			case 'text':
			case 'textarea':
				$(this).val('');
				break;
			case 'checkbox':
			case 'radio':
				$(this).prop('checked', false);
		}
	});
}

function isNumber(n)
{
	return !isNaN(parseFloat(n)) && isFinite(n);
}

function pad(number, length)
{
	var str = '' + number;

	while (str.length < length)
	{
		str = '0' + str;
	}
	
	return str;
}

function show_work_entire_move_container(show)
{
	if(show == true)
	{
		$('#work_entire_move_container').show();
	}
	else
	{
		$('#work_entire_move_container').hide();
	}
}

function scrollToTop()
{
	$('body, html').animate({scrollTop:0}, 'slow');
}

function scrollToBottom()
{
	$('body, html').animate({scrollTop:$(document).height()}, 'slow');
}

function scrollToElement(element, offset)
{
	var el = $(element).offset().top;
	var of = typeof(offset) != 'undefined' ? offset : 0;
	var pos = el - of;
	
	$('body, html').animate({scrollTop:pos}, 'slow');
}