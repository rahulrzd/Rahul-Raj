<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home_model extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }
	
	function _get_employees($id=null, $role=null, $active=true)
	{
		$where = array();
		$order = array('first_name' => 'asc', 'last_name' => 'asc');
		
		if(!empty($id))
		{
			$where['id'] = $id;
		}
		
		if(!empty($role))
		{
			if($role == 'mover')
			{
				$where['mover'] = 1;
			}
			else
			{
				$where['driver'] = 1;
			}
		}
		
		if($active == 'true')
		{
			$where['active'] = 1;
		}
		
		$result = $this->common->_get_data('employees', null, null, $where, null, $order);
		//echo $this->db->last_query();
		
		return $result;
	}
	
	function _insert_employee($employee_data)
	{
		$success = true;
		$where = array('id' => $employee_data['id']);
		$result = $this->common->_get_data('employees', null, null, $where, null, null);
		
		if(count($result))
		{
			//echo '<pre>'.print_r($employee_data, true).'</pre>';
			$result = $this->common->_update_data('employees', $employee_data, $where);
			
			if(!$result)
			{
				$success = false;
			}
		}
		else
		{
			$result = $this->common->_insert_data('employees', $employee_data);
			
			if(!$result)
			{
				$success = false;
			}
		}
		
		return $success;
	}
	
	function _update_employee($employee_data)
	{
		$values = array('active' => 0);
		$where = array('id' => $employee_data['id']);
		$result = $this->common->_update_data('employees', $values, $where);
		
		if($result)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	function _delete_employee($user_id)
	{
		$where = array('id' => $user_id);
		$result = $this->common->_delete_data('employees', $where);
		
		if($result)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	function _insert_employees_time_helper($date_db_format, $truck_select, array $checkboxes, array $employees_time, $gratuity, $role)
	{
		foreach($checkboxes as $driver_key=>$driver_val)
		{
			$success = true;
			$values = array();
			$values2 = array();
			
			$where = array('employees_id' => $driver_val, 'role' => $role, 'date' => $date_db_format);
			$result = $this->common->_get_data('employees_time', null, null, $where, null, null);
			//echo $this->db->last_query();
			
			$values = array(
				'employees_id' => $driver_val,
				'role' => $role,	
				'date' => $date_db_format,
				'truck' => $truck_select,
				'gratuity_display' => $gratuity[$driver_key]
			);
			
			foreach($employees_time as $time_key=>$time_val)
			{
				$pos_am = strpos($time_val, 'am');
				$pos_pm = strpos($time_val, 'pm');
				$pos_am_next_day = strpos($time_val, 'am_next_day');
				
				if($pos_am !== false || $pos_pm !== false || $pos_am_next_day !== false)
				{
					$time_val = date("H:i", strtotime($time_val));
				}
				
				$values2[$time_key] = $time_val;
			}
			
			if(count($result))
			{
				$values = array_merge($values, $values2);
				$result = $this->common->_update_data('employees_time', $values, $where);
				
				if(!$result)
				{
					$success = false;
					break;
				}
			}
			else
			{
				$values = array_merge($values, $values2);
				$result = $this->common->_insert_data('employees_time', $values);
				
				if(!$result)
				{
					$success = false;
					break;
				}
			}
		}
		
		if($success)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	function _get_employee_totals($date_start, $date_end)
	{
		$values = array();
		$date_start = date("Y-m-d", strtotime($date_start));
		$date_end = date("Y-m-d", strtotime($date_end));
		
		$select = array(
			array('e.id'),
			array('CONCAT_WS(" ", e.first_name, e.last_name) AS full_name'),
			array('et.role'),
			array('SUM(et.gratuity_display) AS gratuity'),
			array('SUM(et.total_travel_hours_percent_display) AS total_travel_hours_percent_display'),
			
			array('IF(et.role = "mover", SUM(et.total_pay_move_hours_percent_display), 0) AS total_move_hours_percent_display_mover'),
			array('IF(et.role = "driver", SUM(et.total_pay_move_hours_percent_display), 0) AS total_move_hours_percent_display_driver'),
			
			array('IF(et.role = "mover", SUM(et.total_ot_1_5x_hours_percent_display), 0) AS total_ot_1_5x_hours_percent_display_mover'),
			array('IF(et.role = "driver", SUM(et.total_ot_1_5x_hours_percent_display), 0) AS total_ot_1_5x_hours_percent_display_driver'),
			
			array('IF(et.role = "mover", SUM(et.total_ot_2x_hours_percent_display), 0) AS total_ot_2x_hours_percent_display_mover'),
			array('IF(et.role = "driver", SUM(et.total_ot_2x_hours_percent_display), 0) AS total_ot_2x_hours_percent_display_driver')
		);
		
		$join = array
		(
			array('join_table' => 'employees_time et', 'join' => 'e.id = et.employees_id', 'join_type' => 'left')
		);
		
		$where = array('et.date >=' => $date_start, 'et.date <=' => $date_end, 'e.active' => 1);
		$group_by = array('e.id', 'et.role');
		$order = array('e.first_name' => 'asc', 'e.last_name' => 'asc');
		$result = $this->common->_get_data('employees e', $select, $join, $where, $group_by, $order);
		//echo $this->db->last_query();
		
		//echo '<pre>'.print_r($result, true).'</pre>';exit;
		if($result)
		{
			$values['total_count']['total_travel_hours_percent_display'] = 0;
			
			$values['total_count']['total_move_hours_percent_display_mover'] = 0;
			$values['total_count']['total_move_hours_percent_display_driver'] = 0;
			
			$values['total_count']['total_ot_1_5x_hours_percent_display_mover'] = 0;
			$values['total_count']['total_ot_1_5x_hours_percent_display_driver'] = 0;

			$values['total_count']['total_ot_2x_hours_percent_display_mover'] = 0;
			$values['total_count']['total_ot_2x_hours_percent_display_driver'] = 0;
			
			$values['total_count']['gratuity'] = 0;

			foreach($result as $key=>$val)
			{
				$tmp[$val->id][$val->role]['id'] = $val->id;
				$tmp[$val->id][$val->role]['full_name'] = $val->full_name;
				$tmp[$val->id][$val->role]['total_travel_hours_percent_display'] = $val->total_travel_hours_percent_display;
				
				$tmp[$val->id][$val->role]['total_move_hours_percent_display_mover'] = $val->total_move_hours_percent_display_mover;
				$tmp[$val->id][$val->role]['total_move_hours_percent_display_driver'] = $val->total_move_hours_percent_display_driver;
				
				$tmp[$val->id][$val->role]['total_ot_1_5x_hours_percent_display_mover'] = $val->total_ot_1_5x_hours_percent_display_mover;
				$tmp[$val->id][$val->role]['total_ot_1_5x_hours_percent_display_driver'] = $val->total_ot_1_5x_hours_percent_display_driver;

				$tmp[$val->id][$val->role]['total_ot_2x_hours_percent_display_mover'] = $val->total_ot_2x_hours_percent_display_mover;
				$tmp[$val->id][$val->role]['total_ot_2x_hours_percent_display_driver'] = $val->total_ot_2x_hours_percent_display_driver;

				$tmp[$val->id][$val->role]['gratuity'] = $val->gratuity;
			}
			
			foreach($tmp as $key=>$val)
			{
				$values['data'][$key]['total_travel_hours_percent_display'] = 0;
				
				$values['data'][$key]['total_move_hours_percent_display_mover'] = 0;
				$values['data'][$key]['total_move_hours_percent_display_driver'] = 0;

				$values['data'][$key]['total_ot_1_5x_hours_percent_display_mover'] = 0;
				$values['data'][$key]['total_ot_1_5x_hours_percent_display_driver'] = 0;

				$values['data'][$key]['total_ot_2x_hours_percent_display_mover'] = 0;
				$values['data'][$key]['total_ot_2x_hours_percent_display_driver'] = 0;

				$values['data'][$key]['gratuity'] = 0;
				
				foreach($val as $key2=>$val2)
				{
					$values['data'][$key]['id'] = $val2['id'];
					$values['data'][$key]['full_name'] = $val2['full_name'];
					$values['data'][$key]['total_travel_hours_percent_display'] += $val2['total_travel_hours_percent_display'];
					
					$values['data'][$key]['total_move_hours_percent_display_mover'] += $val2['total_move_hours_percent_display_mover'];
					$values['data'][$key]['total_move_hours_percent_display_driver'] += $val2['total_move_hours_percent_display_driver'];
					
					$values['data'][$key]['total_ot_1_5x_hours_percent_display_mover'] += $val2['total_ot_1_5x_hours_percent_display_mover'];
					$values['data'][$key]['total_ot_1_5x_hours_percent_display_driver'] += $val2['total_ot_1_5x_hours_percent_display_driver'];

					$values['data'][$key]['total_ot_2x_hours_percent_display_mover'] += $val2['total_ot_2x_hours_percent_display_mover'];
					$values['data'][$key]['total_ot_2x_hours_percent_display_driver'] += $val2['total_ot_2x_hours_percent_display_driver'];
					
					$values['data'][$key]['gratuity'] += $val2['gratuity'];

					// Totals
					$values['total_count']['total_travel_hours_percent_display'] += $val2['total_travel_hours_percent_display'];
					
					$values['total_count']['total_move_hours_percent_display_mover'] += $val2['total_move_hours_percent_display_mover'];
					$values['total_count']['total_move_hours_percent_display_driver'] += $val2['total_move_hours_percent_display_driver'];
					
					$values['total_count']['total_ot_1_5x_hours_percent_display_mover'] += $val2['total_ot_1_5x_hours_percent_display_mover'];
					$values['total_count']['total_ot_1_5x_hours_percent_display_driver'] += $val2['total_ot_1_5x_hours_percent_display_driver'];

					$values['total_count']['total_ot_2x_hours_percent_display_mover'] += $val2['total_ot_2x_hours_percent_display_mover'];
					$values['total_count']['total_ot_2x_hours_percent_display_driver'] += $val2['total_ot_2x_hours_percent_display_driver'];

					$values['total_count']['gratuity'] += $val2['gratuity'];
				}
			}
		}
		
		//echo '<pre>'.print_r($values, true).'</pre>';
		
		return $values;
	}
	
	function _get_employee_totals_detail($id, $date_start, $date_end)
	{
		$values = array();
		$date_start = date("Y-m-d", strtotime($date_start));
		$date_end = date("Y-m-d", strtotime($date_end));
		
		$select = array(
			array(
				'e.id',
				'CONCAT_WS(" ", e.first_name, e.last_name) AS full_name',
				'et.id AS et_id',
				'et.role',
				'et.date',
				'et.truck',
				'et.time_in_display',
				'et.first_move_start_display',
				'et.first_move_end_display',
				'et.lunch_start_display',
				'et.lunch_end_display',
				'et.second_move_start_display',
				'et.second_move_end_display',
				'et.time_out_display',
				'et.total_travel_hours_display',
				'et.total_move_hours_display',
				'et.total_travel_hours_percent_display',
				'et.total_move_hours_percent_display',
				'et.total_pay_move_hours_percent_display',
				'et.total_ot_1_5x_hours_percent_display AS total_ot_1_5x_hours_percent_display_mover',
				'et.total_ot_1_5x_hours_percent_display AS total_ot_1_5x_hours_percent_display_driver',
				'et.total_ot_2x_hours_percent_display AS total_ot_2x_hours_percent_display_mover',
				'et.total_ot_2x_hours_percent_display AS total_ot_2x_hours_percent_display_driver',
				'et.gratuity_display AS gratuity'
			)
		);
		
		$join = array
		(
			array('join_table' => 'employees_time et', 'join' => 'e.id = et.employees_id', 'join_type' => 'left')
		);
		
		$where = array('et.date >=' => $date_start, 'et.date <=' => $date_end, 'e.active' => 1, 'e.id' => $id);
		$group_by = null;
		$order = array('et.date' => 'asc');
		$result = $this->common->_get_data('employees e', $select, $join, $where, $group_by, $order);
		//echo $this->db->last_query();
		
		if($result)
		{
			foreach($result as $key=>$val)
			{
				$values[$val->et_id]['emp_id'] = $val->id;
				$values[$val->et_id]['et_id'] = $val->et_id;
				$values[$val->et_id]['date'] = date("l, F d, Y", strtotime($val->date));
				$values[$val->et_id]['truck'] = $val->truck;
				$values[$val->et_id]['time_in_display'] = $val->time_in_display;
				$values[$val->et_id]['first_move_start_display'] = $val->first_move_start_display;
				$values[$val->et_id]['first_move_end_display'] = $val->first_move_end_display;
				$values[$val->et_id]['lunch_start_display'] = $val->lunch_start_display;
				$values[$val->et_id]['lunch_end_display'] = $val->lunch_end_display;
				$values[$val->et_id]['second_move_start_display'] = $val->second_move_start_display;
				$values[$val->et_id]['second_move_end_display'] = $val->second_move_end_display;
				$values[$val->et_id]['time_out_display'] = $val->time_out_display;
				$values[$val->et_id]['total_travel_hours_display'] = $val->total_travel_hours_display;
				$values[$val->et_id]['total_move_hours_display'] = $val->total_move_hours_display;
				$values[$val->et_id]['total_travel_hours_percent_display'] = $val->total_travel_hours_percent_display;
				$values[$val->et_id]['total_move_hours_percent_display'] = $val->total_move_hours_percent_display;
				$values[$val->et_id]['total_pay_move_hours_percent_display'] = $val->total_pay_move_hours_percent_display;
				$values[$val->et_id]['total_ot_1_5x_hours_percent_display_mover'] = $val->total_ot_1_5x_hours_percent_display_mover;
				$values[$val->et_id]['total_ot_1_5x_hours_percent_display_driver'] = $val->total_ot_1_5x_hours_percent_display_driver;
				$values[$val->et_id]['total_ot_2x_hours_percent_display_mover'] = $val->total_ot_2x_hours_percent_display_mover;
				$values[$val->et_id]['total_ot_2x_hours_percent_display_driver'] = $val->total_ot_2x_hours_percent_display_driver;
				$values[$val->et_id]['gratuity'] = $val->gratuity;
			}
		}
		//echo '<pre>'.print_r($values, true).'</pre>';
		return $values;
	}
	
	function _save_employee_details($data)
	{
	    //echo '<pre>'.print_r($data, true).'</pre>';exit;
	    $exclude_convert_time = array(
			'truck',
			'total_travel_hours_display',
			'total_move_hours_display',
			'total_travel_hours_percent_display',
			'total_move_hours_percent_display',
			'total_pay_move_hours_percent_display',
			'total_ot_1_5x_hours_percent_display',
			'total_ot_2x_hours_percent_display',
			'gratuity_display'
	    );
	    
	    $success = true;
	    
	    foreach($data as $k=>$v)
	    {
			if(in_array($v['col_name'], $exclude_convert_time))
			{
				$arr[$v['id']][$v['col_name']] = str_replace('$', '', $v['col_val']);
			}
			else
			{
				if(empty($v['col_val']) || $v['col_val'] == '00:00 am' || $v['col_val'] == '00:00 pm')
				{
					$arr[$v['id']][$v['col_name']] = '00:00:00';
				}
				else
				{
					$arr[$v['id']][$v['col_name']] = date("H:i:s", strtotime($v['col_val']));
				}
			}
	    }
	    
	    foreach($arr as $k=>$v)
	    {
			$where = array('id' => $k);
			$result = $this->common->_update_data('employees_time', $arr[$k], $where);
			//echo $this->db->last_query();
			
			if(!$result)
			{
				$success = false;
				break;
			}
	    }
	    
	    //echo '<pre>'.print_r($arr, true).'</pre>';
	    
	    if($success)
	    {
			return true;
	    }
	    else
	    {
			return false;
	    }
	}
	
	function _delete_employee_details($id)
	{
		$where = array('id' => $id);
		$result = $this->common->_delete_data('employees_time', $where);
		
		if($result)
	    {
			return true;
	    }
	    else
	    {
			return false;
	    }
	}
}

?>