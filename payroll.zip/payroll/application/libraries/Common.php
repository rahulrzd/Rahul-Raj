<?php

class Common
{
	public $db_connect = true;
	
	function __construct()
	{
	    //parent::__construct();
	    $CI =& get_instance();
	
	    if($CI->db->conn_id == false)
	    {
		$CI->db_connect = false;
		//$this->util->log_send_email(__CLASS__, __FUNCTION__, array('err_msg'=>'Could not connect to database'));
	    }
	}
	
	// inserts 1 row using an array of values for the fields that will be added into the specified table
	function _insert_data($table, array $values)
	{
	    $CI =& get_instance();
		    
	    $query = $CI->db->insert($table, $values);
	    
	    if($query)
	    {
		return true;
	    }
	    else
	    {
		$err_no = $CI->db->_error_number();
		$err_msg = $CI->db->_error_message();
		
		if(!empty($err_no))
		{
			//$this->util->log_send_email(__CLASS__, __FUNCTION__, array('query'=>$this->db->queries[0], 'err_no'=>$err_no, 'err_msg'=>$err_msg));
		}
		
		return false;
	    }
	}
	
	// inserts many rows using an array of arrays that contain the field values to be added into the specified table
	function _insert_batch_data($table, array $values)
	{
	    $CI =& get_instance();
	
	    $query = $CI->db->insert_batch($table, $values);
	    
	    if($query)
	    {
		return true;
	    }
	    else
	    {
		$err_no = $CI->db->_error_number();
		$err_msg = $CI->db->_error_message();
		
		if(!empty($err_no))
		{
		    //$this->util->log_send_email(__CLASS__, __FUNCTION__, array('query'=>$this->db->queries[0], 'err_no'=>$err_no, 'err_msg'=>$err_msg));
		}
		
		return false;
	    }
	}
	
	// gets the data from the specified table also allowing you to add a where clause and order the results
	function _get_data($table, array $select=null, array $join=null, array $where=null, array $group_by=null, array $order=null, $limit=null)
	{
	    $CI =& get_instance();
	    
	    if(isset($select))
	    {
		foreach($select as $k=>$v)
		{
		    $CI->db->select($v);
		}
	    }
	    else
	    {
		$CI->db->select('*');
	    }
	    
	    $CI->db->from($table);
	    
	    if(isset($join))
	    {
		foreach($join as $k=>$v)
		{
		    $CI->db->join($v['join_table'], $v['join'], $v['join_type']);
		}
	    }
	    
	    if(isset($where))
	    {
		$CI->db->where($where);
	    }
	
	    if(isset($group_by))
	    {
		foreach($group_by as $k=>$v)
		{
		    $CI->db->group_by($v);
		}
	    }
	    
	    if(isset($order))
	    {
		foreach($order as $k=>$v)
		{
		    $CI->db->order_by($k, $v);
		}
	    }
	    
	    if(isset($limit))
	    {
		$CI->db->limit($limit);
	    }
	    
	    $query = $CI->db->get();
	    
	    $err_no = $CI->db->_error_number();
	    $err_msg = $CI->db->_error_message();
	    
	    if(!empty($err_no))
	    {
		//$this->util->log_send_email(__CLASS__, __FUNCTION__, array('query'=>$this->db->queries[0], 'err_no'=>$err_no, 'err_msg'=>$err_msg));
	    }
	    
	    return $query->result();
	}
	
	// updates a specified table using an array of values and also lets you add a where clause
	function _update_data($table, array $value, array $where=null)
	{
	    $CI =& get_instance();
	
	    if(isset($where))
	    {
		$CI->db->where($where);
	    }
	    
	    $query = $CI->db->update($table, $value);
	    //$query = $this->db->update('some_table', $value);
	    
	    if($query)
	    {
		return true;
	    }
	    else
	    {
		$err_no = $CI->db->_error_number();
		$err_msg = $CI->db->_error_message();
		
		if(!empty($err_no))
		{
		    //$this->util->log_send_email(__CLASS__, __FUNCTION__, array('query'=>$this->db->queries[0], 'err_no'=>$err_no, 'err_msg'=>$err_msg));
		}
		
		return false;
	    }
	}
	
	// updates a specified table for multiple rows using an array of values and also lets you add a where clause
	function _update_batch_data($table, array $value, array $where=null)
	{
	    $CI =& get_instance();
	    /*
	    if(isset($where))
	    {
		$CI->db->where($where);
	    }
	    */
	    $query = $CI->db->update_batch($table, $value, $where);
	    
	    if($query)
	    {
		return true;
	    }
	    else
	    {
		$err_no = $CI->db->_error_number();
		$err_msg = $CI->db->_error_message();
		
		if(!empty($err_no))
		{
		    //$this->util->log_send_email(__CLASS__, __FUNCTION__, array('query'=>$this->db->queries[0], 'err_no'=>$err_no, 'err_msg'=>$err_msg));
		}
		
		return false;
	    }
	}
    
	// deletes from a specified table using an array of values and also lets you add a where clause
	function _delete_data($table, array $where=null)
	{
	    $CI =& get_instance();
	
	    if(isset($where))
	    {
		$CI->db->where($where);
	    }
	    
	    $query = $CI->db->delete($table);
	    
	    if($query)
	    {
		return true;
	    }
	    else
	    {
		$err_no = $CI->db->_error_number();
		$err_msg = $CI->db->_error_message();
		
		if(!empty($err_no))
		{
		    //$this->util->log_send_email(__CLASS__, __FUNCTION__, array('query'=>$this->db->queries[0], 'err_no'=>$err_no, 'err_msg'=>$err_msg));
		}
		
		return false;
	    }
	}

}
?>