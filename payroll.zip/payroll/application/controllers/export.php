<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Export extends CI_Controller {
	
	private $columns = '';
	private $rows = '';
	
	public function __construct()
	{
		parent::__construct();
		//$this->load->dbutil();
		$this->load->model('Home_model');
	}
	
	public function index()
	{
		$url = $this->uri->uri_to_assoc(3);
		
		if($url['type'] == 'csv')
		{
			$startDate = date("Y/m/d", strtotime(str_replace('_', '/', $url['startDate'])));
			$endDate = date("Y/m/d", strtotime(str_replace('_', '/', $url['endDate'])));
			
			$data = $this->Home_model->_get_employee_totals($startDate, $endDate);
			//echo '<pre>'.print_r($data, true).'</pre>';exit;
			
			if(count($data) > 0)
			{
				$file = 'Employee_Totals_'.$url['startDate'].'-'.$url['endDate'].'.csv';
				
				$this->columns = 'Employee Name,Travel HRS,Mover HRS,Driver HRS,Mover 1.5X OT HRS,Driver 1.5X OT HRS,Mover 2X OT HRS,Driver 2X OT HRS,Gratuity'."\n";
				
				foreach($data['data'] as $d)
				{
					$this->rows .= '"'.$d['full_name'].'","'.
						$d['total_travel_hours_percent_display'].'","'.
						$d['total_move_hours_percent_display_mover'].'","'.
						$d['total_move_hours_percent_display_driver'].'","'.
						$d['total_ot_1_5x_hours_percent_display_mover'].'","'.
						$d['total_ot_1_5x_hours_percent_display_driver'].'","'.
						$d['total_ot_2x_hours_percent_display_mover'].'","'.
						$d['total_ot_2x_hours_percent_display_driver'].'","'.
						$d['gratuity'].'"'.
						"\n";
				}
				
				$content = $this->columns.$this->rows;
				
				$this->_outputCSV($file, $content);
			}
		}
	}
	
	function _outputCSV($file, $content)
	{
		header('Content-Description: File Transfer');
		header('Content-type: text/csv');
		header('Content-Disposition: attachment; filename='.basename($file));
		header('Content-Transfer-Encoding: binary');
		header('Expires: 0');
		header('Cache-Control: must-revalidate, post-check=0, pre-check=0');
		header('Pragma: public');
		header('Content-Length: '.strlen($content));
		//ob_clean();
		flush();
		echo $content;
		exit;
	}
	
}