<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller
{
	//private $user_id = 0;
	
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Home_model');
		//$this->user_id = $this->config->item('user_id');
	}
	
	public function index()
	{
		/*
		$day_of_week = date("l");
		
		if($day_of_week == 'Monday')
		{
			$current_week_start = date('l, F d, Y', strtotime('-1 week'));
		}
		else
		{
			$current_week_start = date('l, F d, Y', strtotime('last monday'));
		}
		
		if($day_of_week == 'Sunday')
		{
			$current_week_end = date('l, F d, Y');
		}
		else
		{
			$current_week_end = date('l, F d, Y', strtotime('next sunday +1 week'));
		}
		
		$last_week_start = strtotime('last monday -2 week');
		$last_week_end = strtotime('last monday -1 day');
		
		$data = array(
			'current_week' => $current_week_start.' - '.$current_week_end,
			'last_week' =>  date('l, F d, Y', $last_week_start).' - '.date('l, F d, Y', $last_week_end),
			'current_week_format' => date('m/d/Y', strtotime($current_week_start)).' - '.date('m/d/Y', strtotime($current_week_end)),
			'last_week_format' =>  date('m/d/Y', $last_week_start).' - '.date('m/d/Y', $last_week_end)
		);
		
		//echo '<pre>'.print_r($data, true).'</pre>';
		
		$this->load->view('home', $data);
		*/
		
		$this->load->view('home');
	}
	
	public function get_employees()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id', true);
			$role = $this->input->post('role', true);
			$active = $this->input->post('active', true);
			
			$result = $this->Home_model->_get_employees($id, $role, $active);
			
			if(count($result) > 0)
			{
				$data = array('success' => true, 'msg' => 'Get successful', 'result' => $result);
			}
			else
			{
				$data = array('success' => false, 'msg' => 'No results found!', 'error' => 'No data returned in '.__FUNCTION__, 'result' => $result);
			}
			
			echo json_encode($data);
		}
	}
	
	public function insert_employee()
	{
		if($this->input->is_ajax_request())
		{
			$employee_data = $this->input->post('employee_data', true);
			$delete_user = ($this->input->post('delete_user', true) === 'true') ? true : false;
			
			if($delete_user)
			{
				$employee_data['active'] = 0;
				$result = $this->Home_model->_update_employee($employee_data);
			}
			else
			{
				$employee_data['active'] = 1;
				$result = $this->Home_model->_insert_employee($employee_data);
			}
			
			if($result)
			{
				$data = array('success' => true, 'msg' => 'Insert/Update successful');
			}
			else
			{
				$data = array('success' => false, 'msg' => 'Could not insert employee', 'error' => 'Insert/Update Failed in '.__FUNCTION__);
			}
			
			echo json_encode($data);
		}
	}
	
	public function delete_employee()
	{
		if($this->input->is_ajax_request())
		{
			$user_id = $this->input->post('user_id', true);
			$result = $this->Home_model->_delete_employee($user_id);
			
			if($result)
			{
				$data = array('success' => true, 'msg' => 'Delete successful');
			}
			else
			{
				$data = array('success' => false, 'msg' => 'Could not delete employee', 'error' => 'Delete Failed in '.__FUNCTION__);
			}
			
			echo json_encode($data);
		}
	}

	public function insert_employees_time()
	{
		if($this->input->is_ajax_request())
		{
			$data_driver = false;
			$data_mover = false;
			$date_db_format = date("Y-m-d", strtotime($this->input->post('datepicker', true)));
			$truck_select = $this->input->post('truck_select', true);
			$checkboxes_drivers = $this->input->post('checkboxes_drivers', true);
			$checkboxes_movers = $this->input->post('checkboxes_movers', true);
			$employees_time = $this->input->post('employees_time', true);
			$gratuity_drivers = $this->input->post('gratuity_drivers', true);
			$gratuity_movers = $this->input->post('gratuity_movers', true);
			
			if(is_array($checkboxes_drivers))
			{
				$data_driver = $this->Home_model->_insert_employees_time_helper($date_db_format, $truck_select, $checkboxes_drivers, $employees_time, $gratuity_drivers, 'driver');
			}
			
			if(is_array($checkboxes_movers))
			{
				$data_mover = $this->Home_model->_insert_employees_time_helper($date_db_format, $truck_select, $checkboxes_movers, $employees_time, $gratuity_movers, 'mover');
			}
			
			if($data_driver || $data_mover)
			{
				$data = array('success' => true, 'msg' => 'Insert/Update successful');
			}
			else
			{
				$data = array('success' => false, 'msg' => 'Could not insert employee', 'error' => 'Insert/Update Failed in '.__FUNCTION__);
			}
			
			echo json_encode($data);
		}
	}
	
	public function get_employee_totals()
	{
		if($this->input->is_ajax_request())
		{
			$datepicker_start = $this->input->post('datepicker_start', true);
			$datepicker_end = $this->input->post('datepicker_end', true);
			
			$result = $this->Home_model->_get_employee_totals($datepicker_start, $datepicker_end);
			
			if(count($result) > 0)
			{
				$data = array('success' => true, 'msg' => 'Get successful', 'result' => $result);
			}
			else
			{
				$data = array('success' => false, 'msg' => 'No results found!', 'error' => 'Get Failed in '.__FUNCTION__, 'result' => $result);
			}
			
			echo json_encode($data);
		}
	}
	
	public function get_employee_totals_detail()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id', true);
			$datepicker_start = $this->input->post('datepicker_start', true);
			$datepicker_end = $this->input->post('datepicker_end', true);
			
			$result = $this->Home_model->_get_employee_totals_detail($id, $datepicker_start, $datepicker_end);
			
			if(count($result) > 0)
			{
				$data = array('success' => true, 'msg' => 'Get successful', 'result' => $result);
			}
			else
			{
				$data = array('success' => false, 'msg' => 'No results found!', 'error' => 'Get Failed in '.__FUNCTION__, 'result' => $result);
			}
			
			echo json_encode($data);
		}
	}
	
	public function save_employee_details()
	{
		if($this->input->is_ajax_request())
		{
			$data = $this->input->post('data', true);
			
			$result = $this->Home_model->_save_employee_details($data);
			
			if($result)
			{
				$data = array('success' => true, 'msg' => 'Save successful');
			}
			else
			{
				$data = array('success' => false, 'msg' => 'Could not update employee times', 'error' => 'Update Failed in '.__FUNCTION__);
			}
			
			echo json_encode($data);
		}
	}
	
	public function delete_employee_details()
	{
		if($this->input->is_ajax_request())
		{
			$id = $this->input->post('id', true);
			
			$result = $this->Home_model->_delete_employee_details($id);
			
			if($result)
			{
				$data = array('success' => true, 'msg' => 'Delete successful');
			}
			else
			{
				$data = array('success' => false, 'msg' => 'Could not delete employee times', 'error' => 'Delete Failed in '.__FUNCTION__);
			}
			
			echo json_encode($data);
		}
	}
	
	public function employee_details_template()
	{
		$content = $this->load->view('employee_totals_detail_table', null, true);
		
		if(!empty($content))
		{
			$json = array('success'=>true, 'content'=>$content);
		}
		else
		{
			$json = array('success'=>false, 'msg'=>'An error occurred!');
		}
		
		echo json_encode($json);
	}
}