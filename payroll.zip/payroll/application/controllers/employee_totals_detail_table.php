<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Employee_totals_detail_table extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
	}

	public function index()
	{
		
	}
}