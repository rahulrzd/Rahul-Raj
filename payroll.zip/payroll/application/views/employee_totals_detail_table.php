<?php
$truck_options = array(
	' '=>'',
	'Diesel'=>'Diesel',
	'Great White'=>'Great White',
	'Harwell'=>'Harwell',
	"26' Rental"=>"26' Rental",
	"17' Rental"=>"17' Rental",
	'Labor'=>'Labor',
	'Dirk'=>'Dirk',
	'Kirk Camry'=>'Kirk Camry',
	'Axl'=>'Axl',
	'Bowie'=>'Bowie',
	'Jimi'=>'Jimi'
);
?>
<thead id="thead-{id}">
	<tr>
		<th></th>
		<th></th>
		<th>HR</th>
		<th>MIN</th>
		<th></th>
		<th>TIME</th>
	</tr>
	<tr id="header-{id}" name="header">
		<td colspan="2">{date}<!--<input type="text" class="datepicker_employee_details">--></td>
		<td colspan="2">
			<select id="truck-{id}" name="truck">
				<? foreach($truck_options as $truck) { ?>
					<option value="<?php echo $truck; ?>"><?php echo $truck; ?></option>
				<? } ?>
			</select>
		</td>
		<td colspan="2"><button type="button" id="employee_totals_detail_delete-{id}" name="employee_totals_detail_delete-{id}" value="{date}">Delete Day</button></td>
	</tr>
</thead>
<tbody id="tbody-{id}">
	<tr id="time_in-{id}">
		<td class="bold">Time In</td>
		<td></td>
		<td><input type="text" id="time_in_hours_details-{id}" name="hours" maxlength="2" value="{time_in_hours}" /></td>
		<td><input type="text" id="time_in_minutes_details-{id}" name="minutes" maxlength="2" value="{time_in_minutes}" /></td>
		<td>
			<select id="time_in_am_pm-{id}" name="am_pm">
				<option value="am" {time_in_display_am}>AM</option>
				<option value="pm" {time_in_display_pm}>PM</option>
			</select>
		</td>
		<td><span id="time_in_details_display-{id}" name="display">{time_in_details_display}</span></td>
	</tr>
	<tr id="first_move_start-{id}">
		<td class="bold">1st Move Start</td>
		<td></td>
		<td><input type="text" id="first_move_start_hours_details-{id}" name="hours" maxlength="2" value="{first_move_start_hours}" /></td>
		<td><input type="text" id="first_move_start_minutes_details-{id}" name="minutes" maxlength="2" value="{first_move_start_minutes}" /></td>
		<td>
			<select id="first_move_start_am_pm-{id}" name="am_pm">
				<option value="am" {first_move_start_am}>AM</option>
				<option value="pm" {first_move_start_pm}>PM</option>
			</select>
		</td>
		<td><span id="first_move_start_details_display-{id}" name="display">{first_move_start_details_display}</span></td>
	</tr>
	<tr id="first_move_end-{id}">
		<td class="bold">1st Move End</td>
		<td></td>
		<td><input type="text" id="first_move_end_hours_details-{id}" name="hours" maxlength="2" value="{first_move_end_hours}" /></td>
		<td><input type="text" id="first_move_end_minutes_details-{id}" name="minutes" maxlength="2" value="{first_move_end_minutes}" /></td>
		<td>
			<select id="first_move_end_am_pm-{id}" name="am_pm">
				<option value="am" {first_move_end_am}>AM</option>
				<option value="pm" {first_move_end_pm}>PM</option>
			</select>
		</td>
		<td><span id="first_move_end_details_display-{id}" name="display">{first_move_end_details_display}</span></td>
	</tr>
	<tr id="lunch_start-{id}">
		<td class="bold">Lunch Start/Time Out</td>
		<td></td>
		<td><input type="text" id="lunch_start_hours_details-{id}" name="hours" maxlength="2" value="{lunch_start_hours}" /></td>
		<td><input type="text" id="lunch_start_minutes_details-{id}" name="minutes" maxlength="2" value="{lunch_start_minutes}" /></td>
		<td>
			<select id="lunch_start_am_pm-{id}" name="am_pm">
				<option value="am" {lunch_start_am}>AM</option>
				<option value="pm" {lunch_start_pm}>PM</option>
			</select>
		</td>
		<td><span id="lunch_start_details_display-{id}" name="display">{lunch_start_details_display}</span></td>
	</tr>
	<tr id="lunch_end-{id}">
		<td class="bold">Lunch End</td>
		<td></td>
		<td><input type="text" id="lunch_end_hours_details-{id}" name="hours" maxlength="2" value="{lunch_end_hours}" /></td>
		<td><input type="text" id="lunch_end_minutes_details-{id}" name="minutes" maxlength="2" value="{lunch_end_minutes}" /></td>
		<td>
			<select id="lunch_end_am_pm-{id}" name="am_pm">
				<option value="am" {lunch_end_am}>AM</option>
				<option value="pm" {lunch_end_pm}>PM</option>
			</select>
		</td>
		<td><span id="lunch_end_details_display-{id}" name="display">{lunch_end_details_display}</span></td>
	</tr>
	<tr id="second_move_start-{id}">
		<td class="bold">2nd Move Start</td>
		<td></td>
		<td><input type="text" id="second_move_start_hours_details-{id}" name="hours" maxlength="2" value="{second_move_start_hours}" /></td>
		<td><input type="text" id="second_move_start_minutes_details-{id}" name="minutes" maxlength="2" value="{second_move_start_minutes}" /></td>
		<td>
			<select id="second_move_start_am_pm-{id}" name="am_pm">
				<option value="am" {second_move_start_am}>AM</option>
				<option value="pm" {second_move_start_pm}>PM</option>
			</select>
		</td>
		<td><span id="second_move_start_details_display-{id}" name="display">{second_move_start_details_display}</span></td>
	</tr>
	<tr id="second_move_end-{id}">
		<td class="bold">2nd Move End</td>
		<td></td>
		<td><input type="text" id="second_move_end_hours_details-{id}" name="hours" maxlength="2" value="{second_move_end_hours}" /></td>
		<td><input type="text" id="second_move_end_minutes_details-{id}" name="minutes" maxlength="2" value="{second_move_end_minutes}" /></td>
		<td>
			<select id="second_move_end_am_pm-{id}" name="am_pm">
				<option value="am" {second_move_end_am}>AM</option>
				<option value="pm" {second_move_end_pm}>PM</option>
			</select>
		</td>
		<td><span id="second_move_end_details_display-{id}" name="display">{second_move_end_details_display}</span></td>
	</tr>
	<tr id="time_out-{id}">
		<td class="bold">Time Out</td>
		<td></td>
		<td><input type="text" id="time_out_hours_details-{id}" name="hours" maxlength="2" value="{time_out_hours}" /></td>
		<td><input type="text" id="time_out_minutes_details-{id}" name="minutes" maxlength="2" value="{time_out_minutes}" /></td>
		<td>
			<select id="time_out_am_pm-{id}" name="am_pm">
				<option value="am" {time_out_am}>AM</option>
				<option value="pm" {time_out_pm}>PM</option>
			</select>
		</td>
		<td><span id="time_out_details_display-{id}" name="display">{time_out_details_display}</span></td>
	</tr>
	<tr id="total_travel_hours-{id}">
		<td class="bold">Total Travel Hours</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_travel_hours_details_display-{id}" name="display"><span name="total_hours">0</span>h <span name="total_minutes">0</span>m</td>
	</tr>
	<tr id="total_move_hours-{id}">
		<td class="bold">Total Move Hours</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_move_hours_details_display-{id}" name="display"><span name="total_hours">0</span>h <span name="total_minutes">0</span>m</td>
	</tr>
	<tr id="total_travel_hours_percent-{id}">
		<td class="bold">Travel HR%</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_travel_hours_percent_details_display-{id}" name="display">0.00</td>
	</tr>
	<tr id="total_move_hours_percent-{id}">
		<td class="bold">Total Move HR%</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_move_hours_percent_details_display-{id}" name="display">0.00</td>
	</tr>
	<tr id="total_pay_move_hours_percent-{id}">
		<td class="bold">Regular Pay Move HR%</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_pay_move_hours_percent_details_display-{id}" name="display">0.00</td>
	</tr>
	<tr id="total_ot_1_5x_hours_percent-{id}">
		<td class="bold">1.5X OT HR%</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_ot_1_5x_hours_percent_details_display-{id}" name="display">0.00</td>
	</tr>
	<tr id="total_ot_2x_hours_percent-{id}">
		<td class="bold">2X OT HR%</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="total_ot_2x_hours_percent_details_display-{id}" name="display">0.00</td>
	</tr>
	<tr id="gratuity-{id}">
		<td class="bold">Gratuity</td>
		<td></td>
		<td></td>
		<td></td>
		<td></td>
		<td id="gratuity_details_display-{id}" name="display">0.00</td>
	</tr>
</tbody>
<tfoot id="tfoot-{id}"></tfoot>t>