<?php
$truck_options = array(
	' '=>'',
	'Diesel'=>'Diesel',
	'Great White'=>'Great White',
	'Harwell'=>'Harwell',
	"26' Rental"=>"26' Rental",
	"17' Rental"=>"17' Rental",
	'Labor'=>'Labor',
	'Dirk'=>'Dirk',
	'Kirk Camry'=>'Kirk Camry',
	'Axl'=>'Axl',
	'Bowie'=>'Bowie',
	'Jimi'=>'Jimi'
);
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>REAL RocknRoll Movers Payroll System</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="css/style.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables.css" />
<link rel="stylesheet" type="text/css" href="css/jquery.dataTables_themeroller.css" />
<link rel="stylesheet" type="text/css" href="css/ui-lightness/jquery-ui-1.8.18.custom.css" />
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.8.18.custom.min.js"></script>
<script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="js/script.js"></script>
</head>

<body>

<div id="msg"></div>

<div id="tabs">
	<ul>
		<li><a href="#tabs-blank" class="hidden"></a></li>
		<li><a href="#tabs-add-employee">Add Employee</a></li>
		<li><a href="#tabs-entry-form">Entry Form</a></li>
		<li><a href="#tabs-employee-total">Employee Totals</a></li>
	</ul>
	<div id="tabs-add-employee">
		<div id="employees_container">
			<select id="employees_select" name="employees_select"></select>
		</div>
		<table id="employee_table" name="employee_table" border="1" cellpadding="5" cellspacing="0">
			<thead></thead>
			<tbody>
				<input type="hidden" id="id" name="id" value="" /></td>
				<tr>
					<td>First Name</td>
					<td></td>
					<td><input type="text" id="first_name" name="first_name" class="name" /></td>
				</tr>
				<tr>
					<td>Last Name</td>
					<td></td>
					<td><input type="text" id="last_name" name="last_name" class="name" /></td>
				</tr>
				<tr>
					<td>Type</td>
					<td></td>
					<td>
						<input type="checkbox" id="mover" name="employee_type" value="0" /> Mover
						<input type="checkbox" id="driver" name="employee_type" value="0" /> Driver
					</td>
				</tr>
				<tr>
					<td>Travel Rate</td>
					<td></td>
					<td><input type="text" id="travel_rate" name="travel_rate" class="rates" maxlength="5" value="8.00" /></td>
				</tr>
				<tr id="mover_rate_row" class="hidden">
					<td>Mover Rate</td>
					<td></td>
					<td><input type="text" id="mover_rate" name="mover_rate" class="rates" maxlength="5" value="" /></td>
				</tr>
				<tr id="driver_rate_row" class="hidden">
					<td>Driver Rate</td>
					<td></td>
					<td><input type="text" id="driver_rate" name="driver_rate" class="rates" maxlength="5" value="" /></td>
				</tr>
			</tbody>
			<tfoot>
				<tr>
					<td align="left">
						<input type="checkbox" id="delete_user" name="delete_user" value="0" /> Inactive
					</td>
					<td></td>
					<td align="right">
						<button type="button" id="delete" name="delete">Delete User</button>
						<button type="button" id="submit" name="submit">Add/Update</button>
					</td>
				</tr>
			</tfoot>
		</table>
	</div>
	<div id="tabs-entry-form">
		<div id="entry_form_left">
			<p class="bold">Date: <input type="text" id="datepicker_entry_form"></p>
			
			<div class="bold">Trucks:</div>
			<div id="truck_select_container" name="truck_select_container">
				<?php echo form_dropdown('truck_select', $truck_options, '', 'id="truck_select"'); ?>
			</div>
			
			<div class="bold">Drivers:</div>
			<div id="drivers_container" name="drivers_container"></div>
			
			<div class="bold">Movers:</div>
			<div id="movers_container" name="movers_container"></div>
			
			<div id="work_entire_move_container" class="hidden">
				<div>Did all guys work entire move?</div>
				<input type="radio" id="work_entire_move_yes" name="work_entire_move" value="1" checked="checked" />Yes
				<input type="radio" id="work_entire_move_no" name="work_entire_move" value="0" />No
			</div>
			
			<div id="drivers_movers_container_alt">
				<div class="bold">Drivers:</div>
				<div id="drivers_container_alt" name="drivers_container_alt"></div>
				
				<div class="bold">Movers:</div>
				<div id="movers_container_alt" name="movers_container_alt"></div>
			</div>
		</div>
		
		<div id="entry_form">
			<div class="entry_form_header">Main</div>
			<div id="driver_list_container"><span class="bold">Drivers: </span><div id="driver_list"></div></div>
			<div id="mover_list_container"><span class="bold">Movers: </span><div id="mover_list"></div></div>
			<table id="hours_entry_form" name="hours_entry_form" border="1" cellpadding="5" cellspacing="0">
				<thead>
					<tr>
						<th></th>
						<th></th>
						<th>HR</th>
						<th>MIN</th>
						<th></th>
						<th>TIME</th>
					</tr>
					<tr>
						<td colspan="6"></td>
					</tr>
				</thead>
				<tbody>
					<tr id="time_in">
						<td class="bold">Time In</td>
						<td></td>
						<td><input type="text" id="time_in_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="time_in_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="time_in_am_pm" name="am_pm">
								<option value="am" selected="selected">AM</option>
								<option value="pm">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="time_in_display" name="display"></span></td>
					</tr>
					<tr id="first_move_start">
						<td class="bold">1st Move Start</td>
						<td></td>
						<td><input type="text" id="first_move_start_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="first_move_start_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="first_move_start_am_pm" name="am_pm">
								<option value="am" selected="selected">AM</option>
								<option value="pm">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="first_move_start_display" name="display"></span></td>
					</tr>
					<tr id="first_move_end">
						<td class="bold">1st Move End</td>
						<td></td>
						<td><input type="text" id="first_move_end_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="first_move_end_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="first_move_end_am_pm" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="first_move_end_display" name="display"></span></td>
					</tr>
					<tr id="lunch_start">
						<td class="bold">Lunch Start/Time Out</td>
						<td></td>
						<td><input type="text" id="lunch_start_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="lunch_start_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="lunch_start_am_pm" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="lunch_start_display" name="display"></span></td>
					</tr>
					<tr id="lunch_end">
						<td class="bold">Lunch End</td>
						<td></td>
						<td><input type="text" id="lunch_end_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="lunch_end_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="lunch_end_am_pm" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="lunch_end_display" name="display"></span></td>
					</tr>
					<tr id="second_move_start">
						<td class="bold">2nd Move Start</td>
						<td></td>
						<td><input type="text" id="second_move_start_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="second_move_start_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="second_move_start_am_pm" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="second_move_start_display" name="display"></span></td>
					</tr>
					<tr id="second_move_end">
						<td class="bold">2nd Move End</td>
						<td></td>
						<td><input type="text" id="second_move_end_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="second_move_end_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="second_move_end_am_pm" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="second_move_end_display" name="display"></span></td>
					</tr>
					<tr id="time_out">
						<td class="bold">Time Out</td>
						<td></td>
						<td><input type="text" id="time_out_hours" name="hours" maxlength="2" /></td>
						<td><input type="text" id="time_out_minutes" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="time_out_am_pm" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="time_out_display" name="display"></span></td>
					</tr>
					<tr>
						<td class="bold">Total Travel Hours</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_travel_hours_display" name="display"><span name="total_hours">0</span>h <span name="total_minutes">0</span>m</td>
					</tr>
					<tr>
						<td class="bold">Total Move Hours</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_move_hours_display" name="display"><span name="total_hours">0</span>h <span name="total_minutes">0</span>m</td>
					</tr>
					<tr>
						<td class="bold">Travel HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_travel_hours_percent_display" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">Total Move HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_move_hours_percent_display" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">Regular Pay Move HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_pay_move_hours_percent_display" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">1.5X OT HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_ot_1_5x_hours_percent_display" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">2X OT HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_ot_2x_hours_percent_display" name="display">0.00</td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="6" align="right">
							<button type="button" id="submit" name="submit">Submit</button>
						</td>
					</tr>
				</tfoot>
			</table>
		</div>
		
		<div id="entry_form_alt" class="hidden">
			<div class="entry_form_header">Alternate</div>
			<div id="driver_list_container_alt"><span class="bold">Drivers: </span><div id="driver_list_alt"></div></div>
			<div id="mover_list_container_alt"><span class="bold">Movers: </span><div id="mover_list_alt"></div></div>
			<table id="hours_entry_form_alt" name="hours_entry_form_alt" border="1" cellpadding="5" cellspacing="0">
				<thead>
					<tr>
						<th></th>
						<th></th>
						<th>HR</th>
						<th>MIN</th>
						<th></th>
						<th>TIME</th>
					</tr>
					<tr>
						<td colspan="6"></td>
					</tr>
				</thead>
				<tbody>
					<tr id="time_in_alt">
						<td class="bold">Time In</td>
						<td></td>
						<td><input type="text" id="time_in_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="time_in_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="time_in_am_pm_alt" name="am_pm">
								<option value="am" selected="selected">AM</option>
								<option value="pm">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="time_in_display_alt" name="display"></span></td>
					</tr>
					<tr id="first_move_start_alt">
						<td class="bold">1st Move Start</td>
						<td></td>
						<td><input type="text" id="first_move_start_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="first_move_start_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="first_move_start_am_pm_alt" name="am_pm">
								<option value="am" selected="selected">AM</option>
								<option value="pm">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="first_move_start_display_alt" name="display"></span></td>
					</tr>
					<tr id="first_move_end_alt">
						<td class="bold">1st Move End</td>
						<td></td>
						<td><input type="text" id="first_move_end_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="first_move_end_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="first_move_end_am_pm_alt" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="first_move_end_display_alt" name="display"></span></td>
					</tr>
					<tr id="lunch_start_alt">
						<td class="bold">Lunch Start/Time Out</td>
						<td></td>
						<td><input type="text" id="lunch_start_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="lunch_start_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="lunch_start_am_pm_alt" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="lunch_start_display_alt" name="display"></span></td>
					</tr>
					<tr id="lunch_end_alt">
						<td class="bold">Lunch End</td>
						<td></td>
						<td><input type="text" id="lunch_end_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="lunch_end_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="lunch_end_am_pm_alt" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="lunch_end_display_alt" name="display"></span></td>
					</tr>
					<tr id="second_move_start_alt">
						<td class="bold">2nd Move Start</td>
						<td></td>
						<td><input type="text" id="second_move_start_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="second_move_start_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="second_move_start_am_pm_alt" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="second_move_start_display_alt" name="display"></span></td>
					</tr>
					<tr id="second_move_end_alt">
						<td class="bold">2nd Move End</td>
						<td></td>
						<td><input type="text" id="second_move_end_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="second_move_end_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="second_move_end_am_pm_alt" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="second_move_end_display_alt" name="display"></span></td>
					</tr>
					<tr id="time_out_alt">
						<td class="bold">Time Out</td>
						<td></td>
						<td><input type="text" id="time_out_hours_alt" name="hours" maxlength="2" /></td>
						<td><input type="text" id="time_out_minutes_alt" name="minutes" value="00" maxlength="2" /></td>
						<td>
							<select id="time_out_am_pm_alt" name="am_pm">
								<option value="am">AM</option>
								<option value="pm" selected="selected">PM</option>
								<option value="am_next_day">AM Next Day</option>
							</select>
						</td>
						<td><span id="time_out_display_alt" name="display"></span></td>
					</tr>
					<tr>
						<td class="bold">Total Travel Hours</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_travel_hours_display_alt" name="display"><span name="total_hours">0</span>h <span name="total_minutes">0</span>m</td>
					</tr>
					<tr>
						<td class="bold">Total Move Hours</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_move_hours_display_alt" name="display"><span name="total_hours">0</span>h <span name="total_minutes">0</span>m</td>
					</tr>
					<tr>
						<td class="bold">Travel HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_travel_hours_percent_display_alt" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">Total Move HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_move_hours_percent_display_alt" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">Regular Pay Move HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_pay_move_hours_percent_display_alt" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">1.5X OT HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_ot_1_5x_hours_percent_display_alt" name="display">0.00</td>
					</tr>
					<tr>
						<td class="bold">2X OT HR%</td>
						<td></td>
						<td></td>
						<td></td>
						<td></td>
						<td id="total_ot_2x_hours_percent_display_alt" name="display">0.00</td>
					</tr>
				</tbody>
				<tfoot>
					<tr>
						<td colspan="6" align="right">
							<button type="button" id="submit_alt" name="submit_alt">Submit</button>
						</td>
					</tr>
				</tfoot>
			</table>
		</div>
		
		<div class="clear"></div>
	</div>
	<div id="tabs-employee-total">
		<div id="employee_totals">
			<a href="" id="export_csv" class="bold" target="report_loader">Export CSV</a>
			<p>
			Pay Period<br />
			<!--
			<select id="employee_totals_date_select" name="employee_totals_date_select">
				<option id="current_week" name="current_week" value="<?=$current_week_format?>">Current: <?=$current_week?></option>
				<option id="last_week" name="last_week" value="<?=$last_week_format?>">Previous: <?=$last_week?></option>
				<option id="custom" name="custom" value="custom">Custom</option>
			</select>
			</p>
			<p id="datepicker_employee_totals_container" name="datepicker_employee_totals_container" class="bold, hidden">
			-->
			<p id="datepicker_employee_totals_container" name="datepicker_employee_totals_container" class="bold">
				Date: <input type="text" id="datepicker_employee_totals_start" autocomplete="off"> - <input type="text" id="datepicker_employee_totals_end" autocomplete="off">
			</p>
			<p><button type="button" id="submit_employee_totals" name="submit_employee_totals">Submit</button></p>
			<table id="employee_totals_table" name="employee_totals_table" border="1" cellpadding="5" cellspacing="0">
				<thead>
					<tr>
						<!--<th>ID</th>-->
						<th>Employee Name</th>
						<th>Travel HRS</th>
						<th>Mover HRS</th>
						<th>Driver HRS</th>
						<th>Mover 1.5X OT HRS</th>
						<th>Driver 1.5X OT HRS</th>
						<th>Mover 2X OT HRS</th>
						<th>Driver 2X OT HRS</th>
						<th>Gratuity</th>
					</tr>
				</thead>
				<tbody></tbody>
				<tfoot></tfoot>
			</table>
		</div>
	</div>
</div>

<iframe id="report_loader" name="report_loader" src="" width="0" height="0" class="hidden"></iframe>

<!-- START PREVIEW DIALOG -->
<div id="preview_dialog" title="" style="display:none;">
	<div id="preview_dialog_text" class="preview_dialog">
		<table id="employee_totals_detail_table" name="employee_totals_detail_table" border="1" cellpadding="5" cellspacing="0"></table>
	</div>
</div>
<!-- END PREVIEW DIALOG -->

<!-- START DELETE DIALOG -->
<div id="delete_dialog" title="" style="display:none;">
	<div id="delete_dialog_text" class="delete_dialog"></div>
</div>
<!-- END DELETE DIALOG -->

</body>
</html>